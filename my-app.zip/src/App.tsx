import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";

import Navbar from "./components/Navbar";

import SearchProviders from "./pages/SearchProviders";
import ProviderProfile from "./pages/ProviderProfile";
import ProviderDashboard from "./pages/ProviderDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import CreateProviderProfile from "./pages/CreateProviderProfile";
import CustomerBookings from "./pages/CustomerBookings";
import UploadPortfolio from "./pages/UploadPortfolio";

import Login from "./pages/Login";
import Register from "./pages/Register";
import LandingPage from "./pages/LandingPage";

import ProtectedRoute from "./components/ProtectedRoute";


function AppLayout() {
  const location = useLocation();

  // Hide navbar on landing page
  const hideNavbar = location.pathname === "/";

  return (
    <>
      {!hideNavbar && <Navbar />}

      <Routes>

        {/* ===== LANDING PAGE ===== */}
        <Route path="/" element={<LandingPage />} />

        {/* ===== PUBLIC MARKETPLACE ===== */}
        <Route path="/search" element={<SearchProviders />} />
        <Route path="/provider/:id" element={<ProviderProfile />} />

        {/* ===== AUTH ===== */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* ===== CUSTOMER ===== */}
        <Route
          path="/my-bookings"
          element={
            <ProtectedRoute role="customer">
              <CustomerBookings />
            </ProtectedRoute>
          }
        />

        {/* ===== PROVIDER ===== */}
        <Route
          path="/provider-dashboard"
          element={
            <ProtectedRoute role="provider">
              <ProviderDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/create-provider-profile"
          element={
            <ProtectedRoute role="provider">
              <CreateProviderProfile />
            </ProtectedRoute>
          }
        />

        <Route
          path="/upload-portfolio"
          element={
            <ProtectedRoute role="provider">
              <UploadPortfolio />
            </ProtectedRoute>
          }
        />

        {/* ===== ADMIN ===== */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute role="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

      </Routes>
    </>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AppLayout />
    </BrowserRouter>
  );
}

export default App;