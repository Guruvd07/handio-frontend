export type Language = 'en' | 'hi' | 'mr' | 'bn' | 'ta' | 'te' | 'kn';

export const translations = {
  en: {
    // Navbar
    navbar: {
      login: 'Login',
      register: 'Register',
      search: 'Search',
      myBookings: 'My Bookings',
      dashboard: 'Dashboard',
      createProfile: 'Create Profile',
      admin: 'Admin',
      logout: 'Logout',
    },
    
    // Landing Page
    landing: {
      services: 'Services',
      contact: 'Contact',
    },

    // Hero Section
    hero: {
      trustedBadge: 'Trusted by 50,000+ homeowners',
      titlePart1: 'Find Trusted Local ',
      titlePart2: 'Service Providers',
      subtitle: 'Connect with verified electricians, plumbers, cleaners and professionals. Book instantly. Quality guaranteed.',
      stat1Label: 'Verified Professionals',
      stat2Label: 'Average Rating',
      stat3Label: 'Money-Back Guarantee',
      btnGetStarted: 'Get Started Now',
      btnBecomeProvider: 'Become a Provider',
    },

    // How It Works
    howItWorks: {
      badge: '✦ Simple Process ✦',
      title: 'How Handio Works',
      subtitle: 'A simple 4-step process to get your home services done',
      step1Title: 'Search Service',
      step1Description: 'Find the service you need in just a few clicks',
      step1Detail: 'Browse 50+ categories',
      step2Title: 'Book Provider',
      step2Description: 'Choose from verified professionals',
      step2Detail: '100% verified pros',
      step3Title: 'Get Work Done',
      step3Description: 'Sit back while experts complete the job',
      step3Detail: '4.9 avg. rating',
      step4Title: 'Leave Review',
      step4Description: 'Share your experience and rate the service',
      step4Detail: '10K+ reviews monthly',
      progressStep1: 'Step 1',
      progressStep2: 'Step 2',
      progressStep3: 'Step 3',
      progressStep4: 'Step 4',
      footer: 'From booking to completion, we make it effortless',
    },

    // Features Section
    features: {
      title: 'Why Choose Handio',
      feature1: '✔ Verified Providers',
      feature2: '✔ Easy Booking',
      feature3: '✔ Trusted Reviews',
      feature4: '✔ Secure Platform',
    },

    // Login Page
    login: {
      title: 'Welcome Back',
      subtitle: 'Sign in to access your account',
      email: 'Email Address',
      emailPlaceholder: 'you@example.com',
      password: 'Password',
      passwordPlaceholder: '••••••••',
      signIn: 'Sign In',
      signingIn: 'Signing in...',
      noAccount: "Don't have an account?",
      createOne: 'Create one',
      benefitsTitle: 'Why join ServiceHub?',
      benefit1: '✓ Find trusted service providers',
      benefit2: '✓ Easy booking and scheduling',
      benefit3: '✓ Secure payments',
      benefit4: '✓ Customer support 24/7',
      error: 'Login failed. Please try again.',
    },

    // Register Page
    register: {
      title: 'Create Account',
      subtitle: 'Join ServiceHub today',
      customerRole: '👤 Customer',
      providerRole: '🏢 Service Provider',
      fullName: 'Full Name',
      fullNamePlaceholder: 'John Doe',
      email: 'Email Address',
      emailPlaceholder: 'you@example.com',
      password: 'Password',
      passwordPlaceholder: '••••••••',
      create: 'Create Account',
      creating: 'Creating Account...',
      haveAccount: 'Already have an account?',
      signIn: 'Sign in',
      fillAllFields: 'Please fill in all fields',
      benefitsTitle: 'As a Customer',
      benefitsTitle2: 'As a Provider',
      benefitCust1: '✓ Find local service providers',
      benefitCust2: '✓ Book with confidence',
      benefitCust3: '✓ Track your bookings',
      benefitCust4: '✓ Leave reviews & ratings',
      benefitProv1: '✓ Build your profile',
      benefitProv2: '✓ Accept service requests',
      benefitProv3: '✓ Manage your schedule',
      benefitProv4: '✓ Grow your business',
      error: 'Registration failed. Please try again.',
    },

    // Contact Section
    contact: {
      title: 'Contact Us',
      email: 'Email: support@handio.com',
      phone: 'Phone: +91 9876543210',
      location: 'Location: Pune, Maharashtra',
    },

    // Services Section
    services: {
      title: 'Our Services',
      subtitle: 'Book trusted professionals for everyday home services',
      bookNow: 'Book Now',
      electrician: 'Electrician',
      electricianDesc: 'Trusted electrical work',
      plumber: 'Plumber',
      plumberDesc: 'Professional plumbing',
      cleaning: 'Cleaning',
      cleaningDesc: 'Thorough cleaning services',
      acRepair: 'AC Repair',
      acRepairDesc: 'Expert cooling solutions',
      painting: 'Painting',
      paintingDesc: 'Quality paint work',
    },

    // Search Providers
    searchProviders: {
      title: 'Find Perfect Service Providers',
      subtitle: 'Discover trusted professionals in your area',
      selectCategory: 'Select Category',
      selectCity: 'Select City',
      selectArea: 'Select Area',
      search: 'Search',
      searching: 'Searching...',
      noResults: 'Start searching to find amazing service providers',
      findingProviders: 'Finding providers...',
      priceNotSpecified: 'Price not specified',
      viewProfile: 'View Profile',
    },

    // Provider Dashboard
    providerDashboard: {
      profilePhoto: 'Your Profile Photo',
      uploadPhoto: 'Upload Photo',
      uploadHint: 'Recommended: square image for best results',
      removePhoto: 'Remove Photo',
      workPortfolio: 'Your Work Portfolio',
      managePortfolio: 'Manage Portfolio',
      bookingRequests: 'Booking Requests',
      manageRequests: 'Manage your service requests',
      totalBookings: 'Total Bookings',
      pending: 'Pending',
      accepted: 'Accepted',
      rejected: 'Rejected',
      loadingBookings: 'Loading bookings...',
      noBookings: 'No bookings to show',
      noPendingBookings: 'No pending bookings',
      notes: 'Notes',
      noAdditionalNotes: 'No additional notes',
      accept: '✓ Accept',
      reject: '✕ Reject',
      markCompleted: '✔ Mark Completed',
    },

    // Customer Bookings
    customerBookings: {
      title: 'My Bookings',
      subtitle: 'Track your service bookings',
      totalBookings: 'Total Bookings',
      pending: 'Pending',
      confirmed: 'Confirmed',
      completed: 'Completed',
      noPending: 'No pending bookings',
      noCompleted: 'No completed bookings',
      provider: 'Provider',
      category: 'Category',
      bookingStatus: 'Booking Status',
      pendingStatus: 'Pending',
      confirmedStatus: 'Confirmed',
      rejectedStatus: 'Rejected',
      completedStatus: 'Completed',
      leaveReview: 'Leave Review ⭐',
      reviewed: '⭐ Reviewed',
    },

    // Provider Profile
    providerProfile: {
      priceNotSpecified: 'Price not specified',
      selectDate: 'Please select a date',
      bookingSuccess: 'Booking successful!',
      bookingFailed: 'Booking failed. Please try again.',
      notLoggedIn: 'Please log in to book',
      bookingDate: 'Booking Date',
      selectBookingDate: 'Select a date',
      additionalNotes: 'Additional Notes',
      enterNotes: 'Enter any special requests...',
      bookNow: 'Book Now',
      reviews: 'Customer Reviews',
      noReviews: 'No reviews yet',
      averageRating: 'Average Rating',
    },

    featuredProviders: {
      title: "Top Rated Professionals",
      viewProfile: "View Profile",
      viewAll: "View All Providers",
      new: "New"
    },

    // Footer
    footer: {
      copyright: '© 2026 Handio. All rights reserved.',
    },

    landing: {
      services: 'Services',
      contact: 'Contact',
      popularServices: 'Popular Services',
      popularServicesSubtitle: "Choose from our top-rated professional services"
    },

    stats: {
      customers: "Happy Customers",
      providers: "Verified Providers",
      cities: "Cities Covered",
      rating: "Average Rating"
    },

    cta: {
      title: "Become a Service Provider",
      subtitle: "Earn money by offering your skills to thousands of customers.",
      button: "Join as Provider"
    },
  },

  hi: {
    // Navbar
    navbar: {
      login: 'लॉगिन करें',
      register: 'पंजीकरण करें',
      search: 'खोज करें',
      myBookings: 'मेरी बुकिंग',
      dashboard: 'डैशबोर्ड',
      createProfile: 'प्रोफाइल बनाएं',
      admin: 'एडमिन',
      logout: 'लॉगआउट करें',
    },
    
    // Landing Page
    landing: {
      services: 'सेवाएं',
      contact: 'संपर्क करें',
    },

    // Hero Section
    hero: {
      trustedBadge: '50,000+ घर मालिकों द्वारा विश्वसनीय',
      titlePart1: 'विश्वसनीय स्थानीय ',
      titlePart2: 'सेवा प्रदाता खोजें',
      subtitle: 'सत्यापित इलेक्ट्रीशियन, प्लम्बर, सफाई कर्मी और पेशेवरों से जुड़ें। तुरंत बुक करें। गुणवत्ता की गारंटी।',
      stat1Label: 'सत्यापित पेशेवर',
      stat2Label: 'औसत रेटिंग',
      stat3Label: 'मनी-बैक गारंटी',
      btnGetStarted: 'अभी शुरू करें',
      btnBecomeProvider: 'प्रदाता बनें',
    },

    // How It Works
    howItWorks: {
      badge: '✦ सरल प्रक्रिया ✦',
      title: 'हैंडिओ कैसे काम करता है',
      subtitle: 'घर की सेवाएं पाने के लिए सरल 4-चरणीय प्रक्रिया',
      step1Title: 'सेवा खोजें',
      step1Description: 'कुछ ही क्लिक में आपकी आवश्यक सेवा खोजें',
      step1Detail: '50+ श्रेणियां ब्राउज करें',
      step2Title: 'प्रदाता बुक करें',
      step2Description: 'सत्यापित पेशेवरों में से चुनें',
      step2Detail: '100% सत्यापित पेशेवर',
      step3Title: 'काम पूरा करवाएं',
      step3Description: 'विशेषज्ञों को काम पूरा करने दें',
      step3Detail: '4.9 औसत रेटिंग',
      step4Title: 'समीक्षा दें',
      step4Description: 'अपना अनुभव साझा करें और सेवा को रेट करें',
      step4Detail: 'प्रति माह 10K+ समीक्षाएं',
      progressStep1: 'चरण 1',
      progressStep2: 'चरण 2',
      progressStep3: 'चरण 3',
      progressStep4: 'चरण 4',
      footer: 'बुकिंग से पूरा होने तक, हम इसे आसान बनाते हैं',
    },

    // Features Section
    features: {
      title: 'हैंडिओ क्यों चुनें',
      feature1: '✔ सत्यापित प्रदाता',
      feature2: '✔ आसान बुकिंग',
      feature3: '✔ विश्वसनीय समीक्षाएं',
      feature4: '✔ सुरक्षित मंच',
    },

 
      featuredProviders: {
        title: "शीर्ष रेटेड प्रोफेशनल्स",
        viewProfile: "प्रोफाइल देखें",
        viewAll: "सभी प्रोवाइडर देखें",
        new: "नया"
      },

    // Login Page
    login: {
      title: 'स्वागत है वापस',
      subtitle: 'अपने खाते में साइन इन करें',
      email: 'ईमेल पता',
      emailPlaceholder: 'आप@उदाहरण.कॉम',
      password: 'पासवर्ड',
      passwordPlaceholder: '••••••••',
      signIn: 'साइन इन करें',
      signingIn: 'साइन इन जारी है...',
      noAccount: 'खाता नहीं है?',
      createOne: 'एक बनाएं',
      benefitsTitle: 'ServiceHub में क्यों शामिल हों?',
      benefit1: '✓ विश्वसनीय सेवा प्रदाता खोजें',
      benefit2: '✓ आसान बुकिंग और शेड्यूलिंग',
      benefit3: '✓ सुरक्षित भुगतान',
      benefit4: '✓ 24/7 ग्राहक सहायता',
      error: 'लॉगिन विफल। कृपया फिर से प्रयास करें।',
    },

    // Register Page
    register: {
      title: 'खाता बनाएं',
      subtitle: 'आज ServiceHub में शामिल हों',
      customerRole: '👤 ग्राहक',
      providerRole: '🏢 सेवा प्रदाता',
      fullName: 'पूरा नाम',
      fullNamePlaceholder: 'जॉन डो',
      email: 'ईमेल पता',
      emailPlaceholder: 'आप@उदाहरण.कॉम',
      password: 'पासवर्ड',
      passwordPlaceholder: '••••••••',
      create: 'खाता बनाएं',
      creating: 'खाता बनाया जा रहा है...',
      haveAccount: 'पहले से खाता है?',
      signIn: 'साइन इन करें',
      fillAllFields: 'कृपया सभी फील्ड भरें',
      benefitsTitle: 'ग्राहक के रूप में',
      benefitsTitle2: 'प्रदाता के रूप में',
      benefitCust1: '✓ स्थानीय सेवा प्रदाता खोजें',
      benefitCust2: '✓ आत्मविश्वास के साथ बुक करें',
      benefitCust3: '✓ अपनी बुकिंग ट्रैक करें',
      benefitCust4: '✓ समीक्षा और रेटिंग दें',
      benefitProv1: '✓ अपनी प्रोफाइल बनाएं',
      benefitProv2: '✓ सेवा अनुरोध स्वीकार करें',
      benefitProv3: '✓ अपना शेड्यूल प्रबंधित करें',
      benefitProv4: '✓ अपना व्यवसाय बढ़ाएं',
      error: 'पंजीकरण विफल। कृपया फिर से प्रयास करें।',
    },

    // Contact Section
    contact: {
      title: 'हमसे संपर्क करें',
      email: 'ईमेल: support@handio.com',
      phone: 'फोन: +91 9876543210',
      location: 'स्थान: पुणे, महाराष्ट्र',
    },

    // Services Section
    services: {
      title: 'हमारी सेवाएं',
      subtitle: 'दैनिक घरेलू सेवाओं के लिए विश्वसनीय पेशेवरों को बुक करें',
      bookNow: 'अभी बुक करें',
      electrician: 'इलेक्ट्रीशियन',
      electricianDesc: 'विश्वसनीय विद्युत कार्य',
      plumber: 'प्लंबर',
      plumberDesc: 'पेशेवार प्लंबिंग',
      cleaning: 'सफाई',
      cleaningDesc: 'संपूर्ण सफाई सेवाएं',
      acRepair: 'AC मरम्मत',
      acRepairDesc: 'विशेषज्ञ शीतलन समाधान',
      painting: 'पेंटिंग',
      paintingDesc: 'गुणवत्ता पेंट कार्य',
    },

    // Search Providers
    searchProviders: {
      title: 'परफेक्ट सेवा प्रदाता खोजें',
      subtitle: 'अपने क्षेत्र में विश्वसनीय पेशेवरों की खोज करें',
      selectCategory: 'श्रेणी चुनें',
      selectCity: 'शहर चुनें',
      selectArea: 'क्षेत्र चुनें',
      search: 'खोजें',
      searching: 'खोज जारी है...',
      noResults: 'आश्चर्यजनक सेवा प्रदाताओं को खोजने के लिए खोज शुरू करें',
      findingProviders: 'प्रदाता खोज रहे हैं...',
      priceNotSpecified: 'कीमत निर्दिष्ट नहीं है',
      viewProfile: 'प्रोफाइल देखें',
    },

    // Provider Dashboard
    providerDashboard: {
      profilePhoto: 'आपकी प्रोफाइल फोटो',
      uploadPhoto: 'फोटो अपलोड करें',
      uploadHint: 'सिफारिश: सर्वोत्तम परिणामों के लिए वर्ग छवि',
      removePhoto: 'फोटो हटाएं',
      workPortfolio: 'आपका कार्य पोर्टफोलियो',
      managePortfolio: 'पोर्टफोलियो प्रबंधित करें',
      bookingRequests: 'बुकिंग अनुरोध',
      manageRequests: 'अपने सेवा अनुरोधों को प्रबंधित करें',
      totalBookings: 'कुल बुकिंग',
      pending: 'लंबित',
      accepted: 'स्वीकृत',
      rejected: 'अस्वीकृत',
      loadingBookings: 'बुकिंग लोड हो रही हैं...',
      noBookings: 'दिखाने के लिए कोई बुकिंग नहीं',
      noPendingBookings: 'कोई लंबित बुकिंग नहीं',
      notes: 'नोट्स',
      noAdditionalNotes: 'कोई अतिरिक्त नोट्स नहीं',
      accept: '✓ स्वीकार करें',
      reject: '✕ अस्वीकार करें',
      markCompleted: '✔ पूर्ण के रूप में चिह्नित करें',
    },

    // Customer Bookings
    customerBookings: {
      title: 'मेरी बुकिंग',
      subtitle: 'अपनी सेवा बुकिंग ट्रैक करें',
      totalBookings: 'कुल बुकिंग',
      pending: 'लंबित',
      confirmed: 'पुष्टि किया गया',
      completed: 'पूर्ण',
      noPending: 'कोई लंबित बुकिंग नहीं',
      noCompleted: 'कोई पूर्ण बुकिंग नहीं',
      provider: 'प्रदाता',
      category: 'श्रेणी',
      bookingStatus: 'बुकिंग स्थिति',
      pendingStatus: 'लंबित',
      confirmedStatus: 'पुष्टि किया गया',
      rejectedStatus: 'अस्वीकृत',
      completedStatus: 'पूर्ण',
      leaveReview: 'समीक्षा छोड़ें ⭐',
      reviewed: '⭐ समीक्षा की गई',
    },

    // Provider Profile
    providerProfile: {
      priceNotSpecified: 'कीमत निर्दिष्ट नहीं है',
      selectDate: 'कृपया एक तारीख चुनें',
      bookingSuccess: 'बुकिंग सफल!',
      bookingFailed: 'बुकिंग विफल। कृपया फिर से प्रयास करें।',
      notLoggedIn: 'बुक करने के लिए कृपया लॉगिन करें',
      bookingDate: 'बुकिंग की तारीख',
      selectBookingDate: 'एक तारीख चुनें',
      additionalNotes: 'अतिरिक्त नोट्स',
      enterNotes: 'कोई विशेष अनुरोध दर्ज करें...',
      bookNow: 'अभी बुक करें',
      reviews: 'ग्राहक समीक्षाएं',
      noReviews: 'अभी तक कोई समीक्षा नहीं',
      averageRating: 'औसत रेटिंग',
    },

    // Contact Section
    contact: {
      title: 'हमसे संपर्क करें',
      email: 'ईमेल: support@handio.com',
      phone: 'फोन: +91 9876543210',
      location: 'स्थान: पुणे, महाराष्ट्र',
    },

    // Services Section
    services: {
      title: 'हमारी सेवाएं',
      subtitle: 'दैनिक घरेलू सेवाओं के लिए विश्वसनीय पेशेवरों को बुक करें',
      bookNow: 'अभी बुक करें',
      electrician: 'इलेक्ट्रीशियन',
      electricianDesc: 'विश्वसनीय विद्युत कार्य',
      plumber: 'प्लंबर',
      plumberDesc: 'पेशेवार प्लंबिंग',
      cleaning: 'सफाई',
      cleaningDesc: 'संपूर्ण सफाई सेवाएं',
      acRepair: 'AC मरम्मत',
      acRepairDesc: 'विशेषज्ञ शीतलन समाधान',
      painting: 'पेंटिंग',
      paintingDesc: 'गुणवत्ता पेंट कार्य',
    },

    // Search Providers
    searchProviders: {
      title: 'परफेक्ट सेवा प्रदाता खोजें',
      subtitle: 'अपने क्षेत्र में विश्वसनीय पेशेवरों की खोज करें',
      selectCategory: 'श्रेणी चुनें',
      selectCity: 'शहर चुनें',
      selectArea: 'क्षेत्र चुनें',
      search: 'खोजें',
      searching: 'खोज जारी है...',
      noResults: 'आश्चर्यजनक सेवा प्रदाताओं को खोजने के लिए खोज शुरू करें',
      findingProviders: 'प्रदाता खोज रहे हैं...',
      priceNotSpecified: 'कीमत निर्दिष्ट नहीं है',
      viewProfile: 'प्रोफाइल देखें',
    },

    // Provider Dashboard
    providerDashboard: {
      profilePhoto: 'आपकी प्रोफाइल फोटो',
      uploadPhoto: 'फोटो अपलोड करें',
      uploadHint: 'सिफारिश: सर्वोत्तम परिणामों के लिए वर्ग छवि',
      removePhoto: 'फोटो हटाएं',
      workPortfolio: 'आपका कार्य पोर्टफोलियो',
      managePortfolio: 'पोर्टफोलियो प्रबंधित करें',
      bookingRequests: 'बुकिंग अनुरोध',
      manageRequests: 'अपने सेवा अनुरोधों को प्रबंधित करें',
      totalBookings: 'कुल बुकिंग',
      pending: 'लंबित',
      accepted: 'स्वीकृत',
      rejected: 'अस्वीकृत',
      loadingBookings: 'बुकिंग लोड हो रही हैं...',
      noBookings: 'दिखाने के लिए कोई बुकिंग नहीं',
      noPendingBookings: 'कोई लंबित बुकिंग नहीं',
      notes: 'नोट्स',
      noAdditionalNotes: 'कोई अतिरिक्त नोट्स नहीं',
      accept: '✓ स्वीकार करें',
      reject: '✕ अस्वीकार करें',
      markCompleted: '✔ पूर्ण के रूप में चिह्नित करें',
    },

    // Customer Bookings
    customerBookings: {
      title: 'मेरी बुकिंग',
      subtitle: 'अपनी सेवा बुकिंग ट्रैक करें',
      totalBookings: 'कुल बुकिंग',
      pending: 'लंबित',
      confirmed: 'पुष्टि किया गया',
      completed: 'पूर्ण',
      noPending: 'कोई लंबित बुकिंग नहीं',
      noCompleted: 'कोई पूर्ण बुकिंग नहीं',
      provider: 'प्रदाता',
      category: 'श्रेणी',
      bookingStatus: 'बुकिंग स्थिति',
      pendingStatus: 'लंबित',
      confirmedStatus: 'पुष्टि किया गया',
      rejectedStatus: 'अस्वीकृत',
      completedStatus: 'पूर्ण',
      leaveReview: 'समीक्षा छोड़ें ⭐',
      reviewed: '⭐ समीक्षा की गई',
    },

    // Provider Profile
    providerProfile: {
      priceNotSpecified: 'कीमत निर्दिष्ट नहीं है',
      selectDate: 'कृपया एक तारीख चुनें',
      bookingSuccess: 'बुकिंग सफल!',
      bookingFailed: 'बुकिंग विफल। कृपया फिर से प्रयास करें।',
      notLoggedIn: 'बुक करने के लिए कृपया लॉगिन करें',
      bookingDate: 'बुकिंग की तारीख',
      selectBookingDate: 'एक तारीख चुनें',
      additionalNotes: 'अतिरिक्त नोट्स',
      enterNotes: 'कोई विशेष अनुरोध दर्ज करें...',
      bookNow: 'अभी बुक करें',
      reviews: 'ग्राहक समीक्षाएं',
      noReviews: 'अभी तक कोई समीक्षा नहीं',
      averageRating: 'औसत रेटिंग',
      loading: 'प्रदाता लोड हो रहा है...',
      redirecting: 'आपकी बुकिंग पर रीडायरेक्ट हो रहे हैं...',
    },

    // Footer
    footer: {
      copyright: '© 2026 हैंडिओ। सर्वाधिकार सुरक्षित।',
    },

    landing: {
      services: 'सेवाएं',
      contact: 'संपर्क करें',
      popularServices: 'लोकप्रिय सेवाएं',
      popularServicesSubtitle: "हमारी शीर्ष रेटेड पेशेवर सेवाओं में से चुनें"
    },

    stats: {
      customers: "खुश ग्राहक",
      providers: "सत्यापित प्रदाता",
      cities: "सेवा शहर",
      rating: "औसत रेटिंग"
    },
    cta: {
      title: "सेवा प्रदाता बनें",
      subtitle: "अपने कौशल से हजारों ग्राहकों की सेवा करके कमाएं।",
      button: "प्रदाता के रूप में जुड़ें"
    },
  },

  mr: {
    // Navbar
    navbar: {
      login: 'लॉगिन करा',
      register: 'नोंदणी करा',
      search: 'शोध करा',
      myBookings: 'माझ्या बुकिंग',
      dashboard: 'डॅशबोर्ड',
      createProfile: 'प्रोफाइल तयार करा',
      admin: 'प्रशासक',
      logout: 'बाहेर पडा',
    },
    
    // Landing Page
    landing: {
      services: 'सेवा',
      contact: 'संपर्क',
    },

    // Hero Section
    hero: {
      trustedBadge: '50,000+ गृहस्वामींनी विश्वास ठेवलेले',
      titlePart1: 'विश्वासार्ह स्थानिक ',
      titlePart2: 'सेवा प्रदाता शोधा',
      subtitle: 'सत्यापित इलेक्ट्रिशियन, प्लंबर, क्लीनर आणि व्यावसायिकांशी जुडा। तत्काळ बुक करा। गुणवत्ता हमी।',
      stat1Label: 'सत्यापित व्यावसायिक',
      stat2Label: 'सरासरी रेटिंग',
      stat3Label: 'मनी-बॅक गॅरंटी',
      btnGetStarted: 'आज सुरुवात करा',
      btnBecomeProvider: 'प्रदाता व्हा',
    },

    // How It Works
    howItWorks: {
      badge: '✦ सोपी प्रक्रिया ✦',
      title: 'हँडिओ कसे काम करते',
      subtitle: 'घर सेवा मिळविण्याची साधी 4 पायरीची प्रक्रिया',
      step1Title: 'सेवा शोधा',
      step1Description: 'काही क्लिकमध्ये तुमच्या आवश्यक सेवा शोधा',
      step1Detail: '50+ श्रेणी ब्राउज करा',
      step2Title: 'प्रदाता बुक करा',
      step2Description: 'सत्यापित व्यावसायिकांमधून निवडा',
      step2Detail: '100% सत्यापित व्यावसायिक',
      step3Title: 'काम पूर्ण करा',
      step3Description: 'तज्ञांना काम पूर्ण करू दा',
      step3Detail: '4.9 सरासरी रेटिंग',
      step4Title: 'पुनरावलोकन द्या',
      step4Description: 'तुमचा अनुभव शेअर करा आणि सेवा रेट करा',
      step4Detail: 'मासिक 10K+ पुनरावलोकन',
      progressStep1: 'पायरी 1',
      progressStep2: 'पायरी 2',
      progressStep3: 'पायरी 3',
      progressStep4: 'पायरी 4',
      footer: 'बुकिंगपासून पूर्णतेपर्यंत, आम्ही ते सोपे बनवतो',
    },

    // Features Section
    features: {
      title: 'हँडिओ का निवडा',
      feature1: '✔ सत्यापित प्रदाता',
      feature2: '✔ सोपी बुकिंग',
      feature3: '✔ विश्वासार्ह पुनरावलोकन',
      feature4: '✔ सुरक्षित प्लॅटफॉर्म',
    },

      featuredProviders: {
        title: "उत्तम रेटिंग असलेले सेवा प्रदाते",
        viewProfile: "प्रोफाइल पहा",
        viewAll: "सर्व सेवा प्रदाते पहा",
        new: "नवीन"
      },


    // Login Page
    login: {
      title: 'स्वागत आहे परत',
      subtitle: 'तुमच्या खात्यात साइन इन करा',
      email: 'ईमेल पत्ता',
      emailPlaceholder: 'you@example.com',
      password: 'पासवर्ड',
      passwordPlaceholder: '••••••••',
      signIn: 'साइन इन करा',
      signingIn: 'साइन इन करत आहे...',
      noAccount: 'खाता नाही आहे?',
      createOne: 'एक तयार करा',
      benefitsTitle: 'ServiceHub मध्ये का सामील व्हा?',
      benefit1: '✓ विश्वासार्ह सेवा प्रदाता शोधा',
      benefit2: '✓ सोपी बुकिंग आणि शेड्यूलिंग',
      benefit3: '✓ सुरक्षित पेमेंट',
      benefit4: '✓ 24/7 ग्राहक समर्थन',
      error: 'लॉगिन अयोग्य. कृपया पुन्हा प्रयत्न करा.',
    },

    // Register Page
    register: {
      title: 'खाता तयार करा',
      subtitle: 'आज ServiceHub मध्ये सामील व्हा',
      customerRole: '👤 ग्राहक',
      providerRole: '🏢 सेवा प्रदाता',
      fullName: 'संपूर्ण नाव',
      fullNamePlaceholder: 'जॉन डो',
      email: 'ईमेल पत्ता',
      emailPlaceholder: 'you@example.com',
      password: 'पासवर्ड',
      passwordPlaceholder: '••••••••',
      create: 'खाता तयार करा',
      creating: 'खाता तयार होत आहे...',
      haveAccount: 'आधीच खाता आहे?',
      signIn: 'साइन इन करा',
      fillAllFields: 'कृपया सर्व क्षेत्र भरा',
      benefitsTitle: 'ग्राहक म्हणून',
      benefitsTitle2: 'प्रदाता म्हणून',
      benefitCust1: '✓ स्थानिक सेवा प्रदाता शोधा',
      benefitCust2: '✓ आत्मविश्वासाने बुक करा',
      benefitCust3: '✓ तुमची बुकिंग ट्रॅक करा',
      benefitCust4: '✓ पुनरावलोकन आणि रेटिंग द्या',
      benefitProv1: '✓ तुमचे प्रोफाइल तयार करा',
      benefitProv2: '✓ सेवा विनंत्या स्वीकार करा',
      benefitProv3: '✓ तुमचे शेड्यूल व्यवस्थापित करा',
      benefitProv4: '✓ तुमचा व्यवसाय वाढवा',
      error: 'नोंदणी अयोग्य. कृपया पुन्हा प्रयत्न करा.',
    },

    // Contact Section
    contact: {
      title: 'आमच्याशी संपर्क साधा',
      email: 'ईमेल: support@handio.com',
      phone: 'फोन: +91 9876543210',
      location: 'स्थान: पुणे, महाराष्ट्र',
    },

    // Services Section
    services: {
      title: 'आमच्या सेवा',
      subtitle: 'दैनंदिन घरगुती सेवांसाठी विश्वास्त व्यावसायिकांना बुक करा',
      bookNow: 'आज बुक करा',
      electrician: 'विद्युत तांत्रिक',
      electricianDesc: 'विश्वास्त विद्युत कार्य',
      plumber: 'प्लंबर',
      plumberDesc: 'व्यावसायिक प्लंबिंग',
      cleaning: 'स्वच्छता',
      cleaningDesc: 'संपूर्ण साफसफाई सेवा',
      acRepair: 'AC दुरुस्ती',
      acRepairDesc: 'तज्ञ कूलिंग सोल्यूशन',
      painting: 'रंगकाम',
      paintingDesc: 'गुणवत्तेचे रंग कार्य',
    },

    // Search Providers
    searchProviders: {
      title: 'परफेक्ट सेवा प्रदाता शोधा',
      subtitle: 'तुमच्या क्षेत्रातील विश्वास्त व्यावसायिकांचा शोध घ्या',
      selectCategory: 'श्रेणी निवडा',
      selectCity: 'शहर निवडा',
      selectArea: 'क्षेत्र निवडा',
      search: 'शोध',
      searching: 'शोध चालू आहे...',
      noResults: 'आश्चर्यजनक सेवा प्रदातांना शोधण्यासाठी शोध सुरू करा',
      findingProviders: 'प्रदाता शोधत आहे...',
      priceNotSpecified: 'किंमत निर्दिष्ट नाही',
      viewProfile: 'प्रोफाइल पहा',
    },

    // Provider Dashboard
    providerDashboard: {
      profilePhoto: 'तुमचे प्रोफाइल फोटो',
      uploadPhoto: 'फोटो अपलोड करा',
      uploadHint: 'सुझाव: सर्वोत्तम परिणामांसाठी चौरस प्रतिमा',
      removePhoto: 'फोटो हटवा',
      workPortfolio: 'तुमचे कार्य पोर्टफोलियो',
      managePortfolio: 'पोर्टफोलियो व्यवस्थापित करा',
      bookingRequests: 'बुकिंग विनंत्या',
      manageRequests: 'तुमच्या सेवा विनंत्या व्यवस्थापित करा',
      totalBookings: 'एकूण बुकिंग',
      pending: 'प्रलंबित',
      accepted: 'स्वीकृत',
      rejected: 'नाकारले',
      loadingBookings: 'बुकिंग लोड होत आहे...',
      noBookings: 'दाखवण्याकरिता कोणती बुकिंग नाही',
      noPendingBookings: 'कोणती प्रलंबित बुकिंग नाही',
      notes: 'नोट्स',
      noAdditionalNotes: 'कोणती अतिरिक्त नोट्स नाही',
      accept: '✓ स्वीकारा',
      reject: '✕ नाकारा',
      markCompleted: '✔ पूर्ण म्हणून चिन्हांकित करा',
    },

    // Customer Bookings
    customerBookings: {
      title: 'माझ्या बुकिंग',
      subtitle: 'तुमच्या सेवा बुकिंग ट्रॅक करा',
      totalBookings: 'एकूण बुकिंग',
      pending: 'प्रलंबित',
      confirmed: 'पुष्टि केले',
      completed: 'पूर्ण',
      noPending: 'कोणती प्रलंबित बुकिंग नाही',
      noCompleted: 'कोणती पूर्ण बुकिंग नाही',
      provider: 'प्रदाता',
      category: 'श्रेणी',
      bookingStatus: 'बुकिंग स्थिती',
      pendingStatus: 'प्रलंबित',
      confirmedStatus: 'पुष्टि केले',
      rejectedStatus: 'नाकारले',
      completedStatus: 'पूर्ण',
      leaveReview: 'पुनरावलोकन द्या ⭐',
      reviewed: '⭐ पुनरावलोकन केले',
    },

    // Provider Profile
    providerProfile: {
      priceNotSpecified: 'किंमत निर्दिष्ट नाही',
      selectDate: 'कृपया एक तारीख निवडा',
      bookingSuccess: 'बुकिंग यशस्वी!',
      bookingFailed: 'बुकिंग अयोग्य. कृपया पुन्हा प्रयत्न करा.',
      notLoggedIn: 'बुक करण्यासाठी कृपया लॉगिन करा',
      bookingDate: 'बुकिंग तारीख',
      selectBookingDate: 'एक तारीख निवडा',
      additionalNotes: 'अतिरिक्त नोट्स',
      enterNotes: 'कोणतीही विशेष विनंती प्रविष्ट करा...',
      bookNow: 'आज बुक करा',
      reviews: 'ग्राहक पुनरावलोकन',
      noReviews: 'अजून कोणचेही पुनरावलोकन नाही',
      averageRating: 'सरासरी रेटिंग',
      loading: 'प्रदाता लोड होत आहे...',
      redirecting: 'तुमच्या बुकिंगला रीडायरेक्ट करत आहे...',
    },

    // Footer
    footer: {
      copyright: '© 2026 हँडिओ. सर्व अधिकार सुरक्षित.',
    },

    landing: {
      services: 'सेवा',
      contact: 'संपर्क',
      popularServices: 'लोकप्रिय सेवा',
      popularServicesSubtitle: "आमच्या सर्वोत्तम रेटिंग असलेल्या व्यावसायिक सेवांमधून निवडा"
    },

    stats: {
      customers: "आनंदी ग्राहक",
      providers: "सत्यापित प्रदाते",
      cities: "सेवा शहरे",
      rating: "सरासरी रेटिंग"
    },
    cta: {
      title: "सेवा प्रदाता बना",
      subtitle: "तुमच्या कौशल्याने हजारो ग्राहकांना सेवा देऊन कमवा.",
      button: "प्रदाता म्हणून सामील व्हा"
    },
  
  },

  bn: {
    // Navbar
    navbar: {
      login: 'লগইন করুন',
      register: 'নিবন্ধন করুন',
      search: 'অনুসন্ধান করুন',
      myBookings: 'আমার বুকিং',
      dashboard: 'ড্যাশবোর্ড',
      createProfile: 'প্রোফাইল তৈরি করুন',
      admin: 'প্রশাসক',
      logout: 'লগ আউট করুন',
    },
    
    // Landing Page
    landing: {
      services: 'সেবা',
      contact: 'যোগাযোগ করুন',
    },

    // Hero Section
    hero: {
      trustedBadge: '50,000+ গৃহস্বামী দ্বারা বিশ্বস্ত',
      titlePart1: 'বিশ্বস্ত স্থানীয় ',
      titlePart2: 'সেবা প্রদানকারী খুঁজুন',
      subtitle: 'যাচাইকৃত বৈদ্যুতিকবিদ, নদী কাজের মানুষ, পরিষ্কারক এবং পেশাদারদের সাথে সংযোগ করুন। তাৎক্ষণিকভাবে বুক করুন। গুণমানের নিশ্চয়তা।',
      stat1Label: 'যাচাইকৃত পেশাদার',
      stat2Label: 'গড় রেটিং',
      stat3Label: 'অর্থ ফেরত গ্যারান্টি',
      btnGetStarted: 'এখনই শুরু করুন',
      btnBecomeProvider: 'প্রদানকারী হন',
    },

    // How It Works
    howItWorks: {
      badge: '✦ সহজ প্রক্রিয়া ✦',
      title: 'হ্যান্ডিও কীভাবে কাজ করে',
      subtitle: 'ঘর সেবা পেতে সহজ 4-ধাপের প্রক্রিয়া',
      step1Title: 'সেবা খুঁজুন',
      step1Description: 'কয়েকটি ক্লিকেই আপনার প্রয়োজনীয় সেবা খুঁজুন',
      step1Detail: '50+ ক্যাটেগরি ব্রাউজ করুন',
      step2Title: 'প্রদানকারী বুক করুন',
      step2Description: 'যাচাইকৃত পেশাদারদের থেকে নির্বাচন করুন',
      step2Detail: '100% যাচাইকৃত পেশাদার',
      step3Title: 'কাজ সম্পন্ন করুন',
      step3Description: 'বিশেষজ্ঞদের কাজ সম্পন্ন করতে দিন',
      step3Detail: '4.9 গড় রেটিং',
      step4Title: 'পর্যালোচনা দিন',
      step4Description: 'আপনার অভিজ্ঞতা শেয়ার করুন এবং সেবা রেট করুন',
      step4Detail: 'মাসিক 10K+ পর্যালোচনা',
      progressStep1: 'ধাপ 1',
      progressStep2: 'ধাপ 2',
      progressStep3: 'ধাপ 3',
      progressStep4: 'ধাপ 4',
      footer: 'বুকিং থেকে সমাপ্তি পর্যন্ত, আমরা এটি সহজ করে তুলি',
    },

    // Features Section
    features: {
      title: 'কেন হ্যান্ডিও বেছে নিন',
      feature1: '✔ যাচাইকৃত প্রদানকারী',
      feature2: '✔ সহজ বুকিং',
      feature3: '✔ বিশ্বস্ত পর্যালোচনা',
      feature4: '✔ নিরাপদ প্ল্যাটফর্ম',
    },

   
    featuredProviders: {
      title: "শীর্ষ রেটেড পেশাদাররা",
      viewProfile: "প্রোফাইল দেখুন",
      viewAll: "সব প্রদানকারী দেখুন",
      new: "নতুন"
    },

    // Login Page
    login: {
      title: 'স্বাগতম ফিরে',
      subtitle: 'আপনার অ্যাকাউন্টে লগইন করুন',
      email: 'ইমেল ঠিকানা',
      emailPlaceholder: 'you@example.com',
      password: 'পাসওয়ার্ড',
      passwordPlaceholder: '••••••••',
      signIn: 'লগইন করুন',
      signingIn: 'লগইন করছি...',
      noAccount: 'অ্যাকাউন্ট নেই?',
      createOne: 'একটি তৈরি করুন',
      benefitsTitle: 'ServiceHub-এ কেন যোগ দিন?',
      benefit1: '✓ বিশ্বস্ত সেবা প্রদানকারী খুঁজুন',
      benefit2: '✓ সহজ বুকিং এবং সময়সূচী',
      benefit3: '✓ নিরাপদ অর্থপ্রদান',
      benefit4: '✓ 24/7 গ্রাহক সহায়তা',
      error: 'লগইন ব্যর্থ। আবার চেষ্টা করুন।',
    },

    // Register Page
    register: {
      title: 'অ্যাকাউন্ট তৈরি করুন',
      subtitle: 'আজই ServiceHub-এ যোগ দিন',
      customerRole: '👤 গ্রাহক',
      providerRole: '🏢 সেবা প্রদানকারী',
      fullName: 'পূর্ণ নাম',
      fullNamePlaceholder: 'জন ডো',
      email: 'ইমেল ঠিকানা',
      emailPlaceholder: 'you@example.com',
      password: 'পাসওয়ার্ড',
      passwordPlaceholder: '••••••••',
      create: 'অ্যাকাউন্ট তৈরি করুন',
      creating: 'অ্যাকাউন্ট তৈরি হচ্ছে...',
      haveAccount: 'ইতিমধ্যে অ্যাকাউন্ট আছে?',
      signIn: 'লগইন করুন',
      fillAllFields: 'সমস্ত ক্ষেত্র পূরণ করুন',
      benefitsTitle: 'গ্রাহক হিসাবে',
      benefitsTitle2: 'প্রদানকারী হিসাবে',
      benefitCust1: '✓ স্থানীয় সেবা প্রদানকারী খুঁজুন',
      benefitCust2: '✓ আত্মবিশ্বাসের সাথে বুক করুন',
      benefitCust3: '✓ আপনার বুকিং ট্র্যাক করুন',
      benefitCust4: '✓ পর্যালোচনা এবং রেটিং দিন',
      benefitProv1: '✓ আপনার প্রোফাইল তৈরি করুন',
      benefitProv2: '✓ সেবা অনুরোধ গ্রহণ করুন',
      benefitProv3: '✓ আপনার সময়সূচী পরিচালনা করুন',
      benefitProv4: '✓ আপনার ব্যবসা বৃদ্ধি করুন',
      error: 'নিবন্ধন ব্যর্থ। আবার চেষ্টা করুন।',
    },

    // Footer
    footer: {
      copyright: '© 2026 হ্যান্ডিও। সমস্ত অধিকার সংরক্ষিত।',
    },
    landing: {
      services: 'সেবা',
      contact: 'যোগাযোগ',
      popularServices: 'জনপ্রিয় পরিষেবা',
      popularServicesSubtitle: "আমাদের শীর্ষ রেটেড পেশাদার পরিষেবাগুলির মধ্যে থেকে বেছে নিন"
    },

    stats: {
      customers: "খুশি গ্রাহক",
      providers: "যাচাইকৃত পরিষেবা প্রদানকারী",
      cities: "সেবা শহর",
      rating: "গড় রেটিং"
    },
    cta: {
      title: "সেবা প্রদানকারী হন",
      subtitle: "আপনার দক্ষতা ব্যবহার করে হাজারো গ্রাহকের কাছ থেকে আয় করুন।",
      button: "প্রদানকারী হিসেবে যোগ দিন"
    },
  },

  ta: {
    // Navbar
    navbar: {
      login: 'உள்நுழைக',
      register: 'பதிவு செய்க',
      search: 'தேடுக',
      myBookings: 'என் புக்கிங்குகள்',
      dashboard: 'டேஷ்போர்டு',
      createProfile: 'சுயவிவரம் உருவாக்க',
      admin: 'நிர்வாகி',
      logout: 'வெளியேறு',
    },
    
    // Landing Page
    landing: {
      services: 'சேவைகள்',
      contact: 'தொடர்பு',
    },

    // Hero Section
    hero: {
      trustedBadge: '50,000+ வீட்டு உரிமையாளர்களால் நம்பிக்கை வைக்கப்பட்ட',
      titlePart1: 'நம்பகமான உள்ளூர் ',
      titlePart2: 'சேவை வழங்குநர்களைத் தேடுக',
      subtitle: 'சரிபார்க்கப்பட்ட மின்னியல் பொறியாளர்கள், குழாய் தொழிலாளர்கள், சுத்தம் செய்பவர்கள் மற்றும் தொழில் வல்லுநர்களுடன் இணைக்கவும். உடனடியாக முன்பதிவு செய்க. தரம் உறுதி செய்யப்பட்ட.',
      stat1Label: 'சரிபார்க்கப்பட்ட தொழில் வல்லுநர்கள்',
      stat2Label: 'சராசரி மதிப்பீடு',
      stat3Label: 'பணம் திரும்பப் பெறும் உறுதி',
      btnGetStarted: 'இப்போது தொடங்கவும்',
      btnBecomeProvider: 'வழங்குநர் ஆகவும்',
    },

    // How It Works
    howItWorks: {
      badge: '✦ எளிய செயல்முறை ✦',
      title: 'Handio எவ்வாறு செயல்படுகிறது',
      subtitle: 'வீடு சேவைகளைப் பெற எளிய 4 படிகளின் செயல்முறை',
      step1Title: 'சேவை தேடுக',
      step1Description: 'சில கிளிக்குகளில் உங்களுக்கு தேவையான சேவையைத் தேடுக',
      step1Detail: '50+ வகைகள் உலாவுக',
      step2Title: 'வழங்குநரைப் புக் செய்க',
      step2Description: 'சரிபார்க்கப்பட்ட தொழில் வல்லுநர்களிலிருந்து தேர்ந்தெடுக்கவும்',
      step2Detail: '100% சரிபார்க்கப்பட்ட தொழில் வல்லுநர்கள்',
      step3Title: 'வேலை முடிந்து விடுக',
      step3Description: 'வல்லுநர்கள் வேலையை முடிக்க விடுக',
      step3Detail: '4.9 சராசரி மதிப்பீடு',
      step4Title: 'மதிப்பாய்வு கூறவும்',
      step4Description: 'உங்கள் அனுபவத்தைப் பகிர்ந்து கொள்ளுங்கள் மற்றும் சேவைக்கு மதிப்பீடு கொடுங்கள்',
      step4Detail: 'மாதத்திற்கு 10K+ மதிப்பாய்வுகள்',
      progressStep1: 'படி 1',
      progressStep2: 'படி 2',
      progressStep3: 'படி 3',
      progressStep4: 'படி 4',
      footer: 'முன்பதிவு முதல் முடிவு வரை, நாங்கள் இதை எளிதாக்குகிறோம்',
    },

    // Features Section
    featuredProviders: {
      title: "சிறந்த மதிப்பீடு பெற்ற நிபுணர்கள்",
      viewProfile: "சுயவிவரம் பார்க்க",
      viewAll: "அனைத்து வழங்குநர்களையும் பார்க்க",
      new: "புதியது"
    },

    // Login Page
    login: {
      title: 'மீண்டும் வரவேற்கிறோம்',
      subtitle: 'உங்கள் கணக்கில் உள்நுழைக',
      email: 'மின்னஞ்சல் முகவரி',
      emailPlaceholder: 'you@example.com',
      password: 'கடவுச்சொல்',
      passwordPlaceholder: '••••••••',
      signIn: 'உள்நுழைக',
      signingIn: 'உள்நுழைகிறது...',
      noAccount: 'கணக்கு இல்லையா?',
      createOne: 'ஒன்றை உருவாக்கவும்',
      benefitsTitle: 'ServiceHub-க்கு ஏன் சேர வேண்டும்?',
      benefit1: '✓ நம்பகமான சேவை வழங்குநர்களைத் தேடுக',
      benefit2: '✓ எளிய புக்கிங் மற்றும் அட்டவணை',
      benefit3: '✓ பாதுகாப்பான பேமெண்ட்',
      benefit4: '✓ 24/7 வாடிக்கையாளர் ஆதரவு',
      error: 'உள்நுழைவு தோல்வியடைந்தது. மீண்டும் முயற்சி செய்க.',
    },

    // Register Page
    register: {
      title: 'கணக்கை உருவாக்கவும்',
      subtitle: 'இன்று ServiceHub-க்கு சேர வேண்டும்',
      customerRole: '👤 வாடிக்கையாளர்',
      providerRole: '🏢 சேவை வழங்குநர்',
      fullName: 'முழு பெயர்',
      fullNamePlaceholder: 'ஜான் டோ',
      email: 'மின்னஞ்சல் முகவரி',
      emailPlaceholder: 'you@example.com',
      password: 'கடவுச்சொல்',
      passwordPlaceholder: '••••••••',
      create: 'கணக்கை உருவாக்கவும்',
      creating: 'கணக்கை உருவாக்குகிறது...',
      haveAccount: 'ஏற்கனவே கணக்கு உள்ளதா?',
      signIn: 'உள்நுழைக',
      fillAllFields: 'தயவுசெய்து அனைத்து புலங்களையும் நிரப்பவும்',
      benefitsTitle: 'வாடிக்கையாளராக',
      benefitsTitle2: 'வழங்குநராக',
      benefitCust1: '✓ உள்ளூர் சேவை வழங்குநர்களைத் தேடுக',
      benefitCust2: '✓ நம்பிக்கையுடன் புக் செய்க',
      benefitCust3: '✓ உங்கள் புக்கிங்குகள் கண்காணிக்கவும்',
      benefitCust4: '✓ மதிப்பாய்வுகள் மற்றும் மதிப்பீடுகளை விடவும்',
      benefitProv1: '✓ உங்கள் சுயவிவரத்தை உருவாக்கவும்',
      benefitProv2: '✓ சேவை கோரிக்கைகளை ஏற்றுக்கொள்ளவும்',
      benefitProv3: '✓ உங்கள் அட்டவணையை நிர்வகிக்கவும்',
      benefitProv4: '✓ உங்கள் ব்যবসা பெருக்கவும்',
      error: 'பதிவு தோல்வியடைந்தது. மீண்டும் ���ுயற்சி செய்க.',
    },

    // Footer
    footer: {
      copyright: '© 2026 Handio. அனைத்து உரிமைகளும் সংரक்ഷിত்தாக்கை.',
    },
    landing: {
      services: 'சேவைகள்',
      contact: 'தொடர்பு',
      popularServices: 'பிரபல சேவைகள்',
      popularServicesSubtitle: "எங்கள் சிறந்த மதிப்பீடு செய்யப்பட்ட சேவைகளில் இருந்து தேர்வு செய்யுங்கள்"
    },  

    stats: {
      customers: "மகிழ்ச்சியான வாடிக்கையாளர்கள்",
      providers: "சரிபார்க்கப்பட்ட சேவை வழங்குநர்கள்",
      cities: "சேவை நகரங்கள்",
      rating: "சராசரி மதிப்பீடு"
    },
    cta: {
      title: "சேவை வழங்குநராக சேருங்கள்",
      subtitle: "உங்கள் திறமைகளை பயன்படுத்தி ஆயிரக்கணக்கான வாடிக்கையாளர்களிடம் இருந்து சம்பாதிக்கவும்.",
      button: "வழங்குநராக சேரவும்"
    },
  },

  te: {
    // Navbar
    navbar: {
      login: 'లాగిన్ చేయండి',
      register: 'నమోదు చేయండి',
      search: 'వెతకండి',
      myBookings: 'నా బుకింగ్‌లు',
      dashboard: 'డ్యాష్‌బోర్డ్',
      createProfile: 'ప్రొఫైల్ సృష్టించండి',
      admin: 'నిర్వాహకుడు',
      logout: 'లాగ్ అవుట్',
    },
    
    // Landing Page
    landing: {
      services: 'సేవలు',
      contact: 'సంపర్కం',
    },

    // Hero Section
    hero: {
      trustedBadge: '50,000+ ఇల్లు యజమానులచే విశ్వసించిన',
      titlePart1: 'నమ్మదగిన స్థానిక ',
      titlePart2: 'సేవా ప్రదాతలను కనుగొనండి',
      subtitle: 'ధృవీకృత విద్యుత్ సిద్ధం, నాలుకలు, శుభ్రత చేసేవారు మరియు నిపుణులతో కనెక్ట్ చేయండి. తక్షణమే బుక్ చేయండి. గుణమానం హామీ.',
      stat1Label: 'ధృవీకృత నిపుణులు',
      stat2Label: 'సగటు రేటింగ్',
      stat3Label: 'డబ్బు తిరిగి కమిషన్',
      btnGetStarted: 'ఇప్పుడే ప్రారంభించండి',
      btnBecomeProvider: 'ప్రదాత అయండి',
    },

    // How It Works
    howItWorks: {
      badge: '✦ సరళ ప్రక్రియ ✦',
      title: 'హ్యాండియో ఎలా పనిచేస్తుందో',
      subtitle: 'ఇంటి సేవలను పొందడానికి సరళ 4-దశల ప్రక్రియ',
      step1Title: 'సేవను వెతకండి',
      step1Description: 'కొన్ని క్లిక్‌లలో మీకు కావలసిన సేవను కనుగొనండి',
      step1Detail: '50+ వర్గాలను విషయ చేయండి',
      step2Title: 'ప్రదాతను బుక్ చేయండి',
      step2Description: 'ధృవీకృత నిపుణుల నుండి ఎంచుకోండి',
      step2Detail: '100% ధృవీకృత నిపుణులు',
      step3Title: 'పని పూర్తి చేయండి',
      step3Description: 'నిపుణులు పనిని పూర్తి చేయనివ్వండి',
      step3Detail: '4.9 సగటు రేటింగ్',
      step4Title: 'సమీక్ష ఇవ్వండి',
      step4Description: 'మీ అనుభవాన్ని భాగస్వామ్యం చేసి సేవను రేట్ చేయండి',
      step4Detail: 'నెలకు 10K+ సమీక్షలు',
      progressStep1: 'దశ 1',
      progressStep2: 'దశ 2',
      progressStep3: 'దశ 3',
      progressStep4: 'దశ 4',
      footer: 'బుకింగ్ నుండి పూర్తి వరకు, మేము దీన్ని సులభతరం చేస్తాము',
    },

    // Features Section
    features: {
      title: 'హ్యాండియోను ఎందుకు ఎంచుకోండి',
      feature1: '✔ ధృవీకృత ప్రదాతలు',
      feature2: '✔ సులభమైన బుకింగ్',
      feature3: '✔ నమ్మదగిన సమీక్షలు',
      feature4: '✔ సురక్ష ప్ల్యాట్‌ఫార్మ్',
    },

    featuredProviders: {
      title: "అత్యుత్తమ రేటింగ్ పొందిన నిపుణులు",
      viewProfile: "ప్రొఫైల్ చూడండి",
      viewAll: "అన్ని ప్రొవైడర్లను చూడండి",
      new: "కొత్త"
    },

    // Login Page
    login: {
      title: 'తిరిగి స్వాగతం',
      subtitle: 'మీ ఖాతాకు లాగిన్ చేయండి',
      email: 'ఇమెయిల్ చిరునామా',
      emailPlaceholder: 'you@example.com',
      password: 'పాస్‌వర్డ్',
      passwordPlaceholder: '••••••••',
      signIn: 'లాగిన్ చేయండి',
      signingIn: 'లాగిన్ చేస్తోంది...',
      noAccount: 'ఖాతా లేదా?',
      createOne: 'ఒకటి సృష్టించండి',
      benefitsTitle: 'ServiceHub కు ఎందుకు చేరిన్నాలి?',
      benefit1: '✓ నమ్మదగిన సేవా ప్రదాతలను కనుగొనండి',
      benefit2: '✓ సులభమైన బుకింగ్ మరియు షెడ్యూలింగ్',
      benefit3: '✓ సురక్ష చెల్లింపులు',
      benefit4: '✓ 24/7 కస్టమర్ సపోర్ట్',
      error: 'లాగిన్ విఫలమైంది. మళ్లీ ప్రయత్నం చేయండి.',
    },

    // Register Page
    register: {
      title: 'ఖాతాను సృష్టించండి',
      subtitle: 'ఈ రోజు ServiceHub కు చేరిన్నాలి',
      customerRole: '👤 గ్రాహకుడు',
      providerRole: '🏢 సేవా ప్రదాత',
      fullName: 'పూర్తి నাం',
      fullNamePlaceholder: 'జాన్ డో',
      email: 'ఇమెయిల్ చిరునామా',
      emailPlaceholder: 'you@example.com',
      password: 'పాస్‌వర్డ్',
      passwordPlaceholder: '••••••••',
      create: 'ఖాతాను సృష్టించండి',
      creating: 'ఖాతాను సృష్టిస్తోంది...',
      haveAccount: 'ఇప్పటికే ఖాత ఉందా?',
      signIn: 'లాగిన్ చేయండి',
      fillAllFields: 'దయచేసి అన్ని ఖాళీలను నింపండి',
      benefitsTitle: 'గ్రాహకుడిగా',
      benefitsTitle2: 'ప్రదాతగా',
      benefitCust1: '✓ స్థానిక సేవా ప్రదాతలను కనుగొనండి',
      benefitCust2: '✓ విశ్వాసంతో బుక్ చేయండి',
      benefitCust3: '✓ మీ బుకింగ్‌లను ట్రాక్ చేయండి',
      benefitCust4: '✓ సమీక్షలు మరియు రేటింగ్‌లను ఇవ్వండి',
      benefitProv1: '✓ మీ ప్రొఫైల్‌ను సృష్టించండి',
      benefitProv2: '✓ సేవా అభ్యర్థనలను అంగీకరించండి',
      benefitProv3: '✓ మీ షెడ్యూల్‌ను నిర్వహించండి',
      benefitProv4: '✓ మీ వ్యాపారాన్ని పెంచండి',
      error: 'నమోదు విఫలమైంది. మళ్లీ ప్రయత్నం చేయండి.',
    },

    // Footer
    footer: {
      copyright: '© 2026 హ్యాండియో. అన్ని హక్కులు సంరక్ష్ణలు.',
    },
    landing: {
      services: 'సేవలు',
      contact: 'సంప్రదించండి',
      popularServices: 'ప్రసిద్ధ సేవలు',
      popularServicesSubtitle: "మా అత్యుత్తమ రేటింగ్ పొందిన సేవలలో ఒకదాన్ని ఎంచుకోండి"
    },

    stats: {
      customers: "సంతోషకరమైన కస్టమర్లు",
      providers: "ధృవీకరించిన సేవా ప్రదాతలు",
      cities: "సేవా నగరాలు",
      rating: "సగటు రేటింగ్"
    },
    cta: {
      title: "సేవా ప్రదాతగా మారండి",
      subtitle: "మీ నైపుణ్యాలను ఉపయోగించి వేలాది కస్టమర్ల నుండి సంపాదించండి.",
      button: "ప్రదాతగా చేరండి"
    },
  },

  kn: {
    // Navbar
    navbar: {
      login: 'ಲಾಗಿನ್ ಮಾಡಿ',
      register: 'ನೋಂದಾಯಿಸಿ',
      search: 'ಹುಡುಕಿ',
      myBookings: 'ನನ್ನ ಬುಕಿಂಗ್‌ಗಳು',
      dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
      createProfile: 'ಪ್ರೋಫೈಲ್ ರಚಿಸಿ',
      admin: 'ನಿರ್ವಾಹಕ',
      logout: 'ನಿರ್ಗಮನ',
    },
    
    // Landing Page
    landing: {
      services: 'ಸೇವೆಗಳು',
      contact: 'ಸಂಪರ್ಕ',
    },

    // Hero Section
    hero: {
      trustedBadge: '50,000+ ಮನೆ ಮಾಲಿಕರಿಂದ ವಿಶ್ವಾಸಾರ್ಹ',
      titlePart1: 'ವಿಶ್ವಾಸಾರ್ಹ ಸ್ಥಳೀಯ ',
      titlePart2: 'ಸೇವಾ ಪ್ರದಾತರನ್ನು ಹುಡುಕಿ',
      subtitle: 'ಪರಿಶೀಲಿತ ವಿದ್ಯುತ್ತಿನವರೊಂದಿಗೆ ಸಂಪರ್ಕ ಸಾಧಿಸಿ, ಲೋಹಿತೀಕರಣ, ಸಾಫ್ಟ್‌ವೇರ್ ಎಂಜಿನಿಯರ್‌ಗಳು ಮತ್ತು ವೃತ್ತಿಪರರು. ತಕ್ಷಣ ಬುಕ್ ಮಾಡಿ. ಗುಣಮಾನ ಖಾತರಿ ಪಡಿಸಲಾಗಿದೆ.',
      stat1Label: 'ಪರಿಶೀಲಿತ ವೃತ್ತಿಪರರು',
      stat2Label: 'ಸರಾಸರಿ ರೇಟಿಂಗ್',
      stat3Label: 'ಹಣ-ಮರಳಿ ಖಾತರಿ',
      btnGetStarted: 'ಈಗ ಪ್ರಾರಂಭಿಸಿ',
      btnBecomeProvider: 'ಪ್ರದಾತ ಆಗಿರಿ',
    },

    // How It Works
    howItWorks: {
      badge: '✦ ಸರಳ ಪ್ರಕ್ರಿಯೆ ✦',
      title: 'ಹ್ಯಾಂಡಿಓ ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ',
      subtitle: 'ಮನೆಯ ಸೇವೆಗಳನ್ನು ಪಡೆಯಲು ಸರಳ 4-ಹಂತದ ಪ್ರಕ್ರಿಯೆ',
      step1Title: 'ಸೇವೆ ಹುಡುಕಿ',
      step1Description: 'ಕೆಲವೇ ಕ್ಲಿಕ್‌ಗಳಲ್ಲಿ ನಿಮಗೆ ಬೇಕಾದ ಸೇವೆಯನ್ನು ಹುಡುಕಿ',
      step1Detail: '50+ ವರ್ಗಗಳನ್ನು ಬ್ರೌಸ್ ಮಾಡಿ',
      step2Title: 'ಪ್ರದಾತರನ್ನು ಬುಕ್ ಮಾಡಿ',
      step2Description: 'ಪರಿಶೀಲಿತ ವೃತ್ತಿಪರರಿಂದ ಆರಿಸಿಕೊಳ್ಳಿ',
      step2Detail: '100% ಪರಿಶೀಲಿತ ವೃತ್ತಿಪರರು',
      step3Title: 'ಕೆಲಸ ಪೂರ್ಣ ಮಾಡಿ',
      step3Description: 'ವಿಶೇಷಜ್ಞರನ್ನು ಕೆಲಸ ಪೂರ್ಣ ಮಾಡಲು ವಿಶ್ರಾಮಿಸಿ',
      step3Detail: '4.9 ಸರಾಸರಿ ರೇಟಿಂಗ್',
      step4Title: 'ಪರಿಶೀಲನೆ ನೀಡಿ',
      step4Description: 'ನಿಮ್ಮ ಅನುಭವವನ್ನು ಹಂಚಿಕೊಳ್ಳಿ ಮತ್ತು ಸೇವೆಗೆ ರೇಟಿಂಗ್ ನೀಡಿ',
      step4Detail: 'ತಿಂಗಳಿಗೆ 10K+ ಪರಿಶೀಲನೆಗಳು',
      progressStep1: 'ಹಂತ 1',
      progressStep2: 'ಹಂತ 2',
      progressStep3: 'ಹಂತ 3',
      progressStep4: 'ಹಂತ 4',
      footer: 'ಬುಕಿಂಗ್‌ನಿಂದ ಪೂರ್ಣತೆವರೆಗೆ, ನಾವು ಅದನ್ನು ಸಾಧ್ಯವೆಂದು ಮಾಡುತ್ತೇವೆ',
    },

    // Features Section
    features: {
      title: 'ಹ್ಯಾಂಡಿಓ ಏಕೆ ಆರಿಸಿಕೊಳ್ಳಿ',
      feature1: '✔ ಪರಿಶೀಲಿತ ಪ್ರದಾತರು',
      feature2: '✔ ಸರಳ ಬುಕಿಂಗ್',
      feature3: '✔ ವಿಶ್ವಾಸಾರ್ಹ ಪರಿಶೀಲನೆಗಳು',
      feature4: '✔ ಸುರಕ್ಷಿತ ವೇದಿಕೆ',
    },

    featuredProviders: {
      title: "ಅತ್ಯುತ್ತಮ ರೇಟಿಂಗ್ ಹೊಂದಿರುವ ವೃತ್ತಿಪರರು",
      viewProfile: "ಪ್ರೊಫೈಲ್ ನೋಡಿ",
      viewAll: "ಎಲ್ಲಾ ಸೇವಾ ಪೂರೈಕೆದಾರರನ್ನು ನೋಡಿ",
      new: "ಹೊಸದು"
    },

    // Login Page
    login: {
      title: 'ಮತ್ತೆ ಸ್ವಾಗತ',
      subtitle: 'ನಿಮ್ಮ ಖಾತೆಗೆ ಲಾಗಿನ್ ಮಾಡಿ',
      email: 'ಇಮೇಲ್ ವಿಳಾಸ',
      emailPlaceholder: 'you@example.com',
      password: 'ಪಾಸ್‌ವರ್ಡ್',
      passwordPlaceholder: '••••••••',
      signIn: 'ಲಾಗಿನ್ ಮಾಡಿ',
      signingIn: 'ಲಾಗಿನ್ ಮಾಡುತ್ತಿರುವೆ...',
      noAccount: 'ಖಾತೆ ಇಲ್ಲವೇ?',
      createOne: 'ಒಂದು ರಚಿಸಿ',
      benefitsTitle: 'ServiceHub ಕ್ಕೆ ಏಕೆ ಸೇರಬೇಕು?',
      benefit1: '✓ ವಿಶ್ವಾಸಾರ್ಹ ಸೇವಾ ಪ್ರದಾತರನ್ನು ಹುಡುಕಿ',
      benefit2: '✓ ಸರಳ ಬುಕಿಂಗ್ ಮತ್ತು ವೇಳಾಪಟ್ಟಿ',
      benefit3: '✓ ಸುರಕ್ಷಿತ ಪೇಮೆಂಟ್‌ಗಳು',
      benefit4: '✓ 24/7 ಗ್ರಾಹಕ ಸಹಾಯ',
      error: 'ಲಾಗಿನ್ ವಿಫಲವಾಗಿದೆ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
    },

    // Register Page
    register: {
      title: 'ಖಾತೆ ರಚಿಸಿ',
      subtitle: 'ಇಂದು ServiceHub ಕ್ಕೆ ಸೇರಿ',
      customerRole: '👤 ಗ್ರಾಹಕ',
      providerRole: '🏢 ಸೇವಾ ಪ್ರದಾತ',
      fullName: 'ಪೂರ್ಣ ಹೆಸರು',
      fullNamePlaceholder: 'ಜಾನ್ ಡೋ',
      email: 'ಇಮೇಲ್ ವಿಳಾಸ',
      emailPlaceholder: 'you@example.com',
      password: 'ಪಾಸ್‌ವರ್ಡ್',
      passwordPlaceholder: '••••••••',
      create: 'ಖಾತೆ ರಚಿಸಿ',
      creating: 'ಖಾತೆ ರಚಿಸುತ್ತಿರುವೆ...',
      haveAccount: 'ಈಗಾಗಲೇ ಖಾತೆ ಹೊಂದಿದ್ದೀರೆ?',
      signIn: 'ಲಾಗಿನ್ ಮಾಡಿ',
      fillAllFields: 'ದಯವಿಟ್ಟು ಎಲ್ಲಾ ಕ್ಷೇತ್ರಗಳನ್ನು ತುಂಬಿಸಿ',
      benefitsTitle: 'ಗ್ರಾಹಕ ಆಗಿ',
      benefitsTitle2: 'ಪ್ರದಾತ ಆಗಿ',
      benefitCust1: '✓ ಸ್ಥಳೀಯ ಸೇವಾ ಪ್ರದಾತರನ್ನು ಹುಡುಕಿ',
      benefitCust2: '✓ ಆತ್ಮವಿಶ್ವಾಸದೊಂದಿಗೆ ಬುಕ್ ಮಾಡಿ',
      benefitCust3: '✓ ನಿಮ್ಮ ಬುಕಿಂಗ್‌ಗಳನ್ನು ಟ್ರ್ಯಾಕ್ ಮಾಡಿ',
      benefitCust4: '✓ ಪರಿಶೀಲನೆಗಳು ಮತ್ತು ರೇಟಿಂಗ್‌ಗಳನ್ನು ನೀಡಿ',
      benefitProv1: '✓ ನಿಮ್ಮ ಪ್ರೋಫೈಲ್ ರಚಿಸಿ',
      benefitProv2: '✓ ಸೇವಾ ವಿನಂತಿಗಳನ್ನು ಸ್ವೀಕರಿಸಿ',
      benefitProv3: '✓ ನಿಮ್ಮ ವೇಳಾಪಟ್ಟಿ ನಿರ್ವಹಿಸಿ',
      benefitProv4: '✓ ನಿಮ್ಮ ವ್ಯವಹಾರವನ್ನು ಬೆಳೆಸಿ',
      error: 'ನೋಂದಾಯಿತತೆ ವಿಫಲವಾಗಿದೆ. ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
    },

    // Footer
    footer: {
      copyright: '© 2026 ಹ್ಯಾಂಡಿಓ. ಎಲ್ಲಾ ಹಕ್ಕುಗಳನ್ನು ಸಂರಕ್ಷಿತ.',
    },

    landing: {
      services: 'ಸೇವೆಗಳು',
      contact: 'ಸಂಪರ್ಕಿಸಿ',
      popularServices: 'ಜನಪ್ರಿಯ ಸೇವೆಗಳು',
      popularServicesSubtitle: "ನಮ್ಮ ಅತ್ಯುತ್ತಮ ರೇಟಿಂಗ್ ಪಡೆದ ಸೇವೆಗಳಿಂದ ಆಯ್ಕೆಮಾಡಿ"
    },

    stats: {
      customers: "ಸಂತೋಷದ ಗ್ರಾಹಕರು",
      providers: "ಪರಿಶೀಲಿತ ಸೇವಾ ಪೂರೈಕೆದಾರರು",
      cities: "ಸೇವಾ ನಗರಗಳು",
      rating: "ಸರಾಸರಿ ರೇಟಿಂಗ್"
    },
    cta: {
      title: "ಸೇವಾ ಪೂರೈಕೆದಾರರಾಗಿ ಸೇರಿ",
      subtitle: "ನಿಮ್ಮ ಕೌಶಲ್ಯಗಳನ್ನು ಬಳಸಿ ಸಾವಿರಾರು ಗ್ರಾಹಕರಿಂದ ಆದಾಯ ಗಳಿಸಿ.",
      button: "ಪೂರೈಕೆದಾರರಾಗಿ ಸೇರಿ"
    },
  },
};
