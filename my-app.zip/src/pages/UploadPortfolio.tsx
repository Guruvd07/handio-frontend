import { useEffect, useState } from "react";
import api from "../api/axios";
import { useNavigate } from "react-router-dom";
import "./UploadPortfolio.css";

function UploadPortfolio() {

  const navigate = useNavigate();

  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [portfolio, setPortfolio] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  /* =========================
     FETCH PORTFOLIO
  ========================= */

  const fetchPortfolio = async () => {

    try {

      const res = await api.get("/providers/portfolio", {
        headers: {
          "Cache-Control": "no-cache"
        }
      });

      setPortfolio(res.data);

    } catch (err) {

      console.error("Portfolio load failed:", err);

    }

  };

  useEffect(() => {
    fetchPortfolio();
  }, []);

  /* =========================
     UPLOAD IMAGE
  ========================= */

  const handleUpload = async () => {

    if (loading) return;

    if (!file) {
      alert("Select image first");
      return;
    }

    try {

      setLoading(true);

      const formData = new FormData();
      formData.append("image", file);
      formData.append("caption", caption);

      await api.post("/providers/portfolio", formData);

      fetchPortfolio();

      setFile(null);
      setCaption("");

    } catch (err) {

      console.error("Upload failed:", err);

    } finally {

      setLoading(false);

    }

  };

  /* =========================
     DELETE IMAGE
  ========================= */

  const handleDelete = async (imageId: string) => {

    if (!window.confirm("Delete this portfolio image?")) return;

    try {

      await api.delete(`/providers/portfolio/${imageId}`);

      // state update
      setPortfolio((prev) =>
        prev.filter((item) => item._id !== imageId)
      );

    } catch (err: any) {

      console.error("Delete failed:", err.response?.data || err);
      alert(err.response?.data?.error || "Delete failed");

    }

  };

  return (

    <div className="portfolio-page">

      <div className="portfolio-header">

        <button
          className="back-btn"
          onClick={() => navigate("/provider-dashboard")}
        >
          ← Back
        </button>

        <h1>Manage Portfolio</h1>

      </div>

      <div className="portfolio-upload">

        <input
          type="file"
          accept="image/*"
          onChange={(e) =>
            setFile(e.target.files?.[0] || null)
          }
        />

        <input
          type="text"
          placeholder="Caption (optional)"
          value={caption}
          onChange={(e) =>
            setCaption(e.target.value)
          }
        />

        <button onClick={handleUpload} disabled={loading}>
          {loading ? "Uploading..." : "Upload"}
        </button>

      </div>

      <div className="portfolio-grid">

        {portfolio.length === 0 ? (

          <p>No portfolio images yet</p>

        ) : (

          portfolio.map((item) => (

            <div key={item._id} className="portfolio-item">

              <img
                src={item.imageUrl}
                alt="portfolio"
              />

              {item.caption && (
                <p>{item.caption}</p>
              )}

              <button
                className="delete-btn"
                onClick={() => handleDelete(item._id)}
              >
                Delete
              </button>

            </div>

          ))

        )}

      </div>

    </div>

  );

}

export default UploadPortfolio;