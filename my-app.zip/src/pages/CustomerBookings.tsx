'use client';

import { useEffect, useState } from "react";
import axios from "axios";
import { useLanguage } from "../context/LanguageContext";
import "./CustomerBookings.css";
import ReviewForm from "../components/ReviewForm";

export default function CustomerBookings() {
  const { t } = useLanguage();
  const [list, setList] = useState<any[]>([]);
  const [filter, setFilter] = useState<string>("all");

  const [selectedBooking, setSelectedBooking] = useState<any | null>(null);
  const [showReviewModal, setShowReviewModal] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const res = await axios.get("http://localhost:5000/bookings/my", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    });

    setList(res.data);
  }

  function openReview(booking: any) {
    setSelectedBooking(booking);
    setShowReviewModal(true);
  }

  const filteredList =
    filter === "all" ? list : list.filter((b) => b.status === filter);

  const stats = {
    total: list.length,
    pending: list.filter((b) => b.status === "pending").length,
    accepted: list.filter((b) => b.status === "accepted").length,
    completed: list.filter((b) => b.status === "completed").length,
  };

  const formatPrice = (provider: any) => {
    if (!provider?.priceAmount) return "Price not specified";

    const type = provider.priceType
      ? provider.priceType.charAt(0).toUpperCase() +
        provider.priceType.slice(1)
      : "";

    return `₹${provider.priceAmount.toLocaleString()}${
      type ? ` / ${type}` : ""
    }`;
  };

  return (
    <div className="customer-bookings-page">

      <div className="bookings-header">
        <h1>{t('customerBookings.title')}</h1>
        <p>{t('customerBookings.subtitle')}</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-number">{stats.total}</span>
          <span className="stat-label">{t('customerBookings.totalBookings')}</span>
        </div>

        <div className="stat-card pending">
          <span className="stat-number">{stats.pending}</span>
          <span className="stat-label">{t('customerBookings.pending')}</span>
        </div>

        <div className="stat-card accepted">
          <span className="stat-number">{stats.accepted}</span>
          <span className="stat-label">{t('customerBookings.confirmed')}</span>
        </div>

        <div className="stat-card completed">
          <span className="stat-number">{stats.completed}</span>
          <span className="stat-label">{t('customerBookings.completed')}</span>
        </div>
      </div>

      <div className="filter-tabs">
        {["all", "pending", "accepted", "completed"].map((status) => {
          const statusLabels: { [key: string]: string } = {
            'all': 'All',
            'pending': t('customerBookings.pending'),
            'accepted': t('customerBookings.confirmed'),
            'completed': t('customerBookings.completed'),
          };

          return (
            <button
              key={status}
              className={`filter-tab ${filter === status ? "active" : ""}`}
              onClick={() => setFilter(status)}
            >
              {statusLabels[status]}
            </button>
          );
        })}
      </div>

      {filteredList.length === 0 ? (
        <div className="no-bookings">
          <p>
            📭 {t('customerBookings.noPending')}
          </p>
        </div>
      ) : (
        <div className="bookings-grid">
          {filteredList.map((b) => (
            <div key={b._id} className={`booking-card status-${b.status}`}>

              <div className="card-header">
                <div className="provider-info">
                  <div className="provider-avatar">
                    {b.providerId?.userId?.name?.charAt(0)?.toUpperCase() || "P"}
                  </div>

                  <div>
                    <h3>{b.providerId?.userId?.name || "Provider"}</h3>
                    <p className="category">{b.providerId?.category}</p>
                  </div>
                </div>

                <div className={`status-badge status-${b.status}`}>
                  {b.status === "pending" && `⏳ ${t('customerBookings.pendingStatus')}`}
                  {b.status === "accepted" && `✓ ${t('customerBookings.confirmedStatus')}`}
                  {b.status === "rejected" && `✕ ${t('customerBookings.rejectedStatus')}`}
                  {b.status === "completed" && `✓ ${t('customerBookings.completedStatus')}`}
                </div>
              </div>

              <div className="card-body">
                <div className="location">
                  📍 {b.providerId?.city} — {b.providerId?.area}
                </div>

                <div className="date">
                  📅 {new Date(b.date).toLocaleDateString()}
                </div>

                {b.note && (
                  <div className="note">
                    📝 {b.note}
                  </div>
                )}
              </div>

              <div className="card-footer">
                <span className="price">
                  {formatPrice(b.providerId)}
                </span>

                {b.status === "completed" && !b.reviewed && (
                  <button
                    className="review-btn"
                    onClick={() => openReview(b)}
                  >
                    {t('customerBookings.leaveReview')}
                  </button>
                )}

                {b.reviewed && (
                  <span className="reviewed-badge">
                    {t('customerBookings.reviewed')}
                  </span>
                )}
              </div>

            </div>
          ))}
        </div>
      )}

      {showReviewModal && selectedBooking && (
        <ReviewForm
          booking={selectedBooking}
          onClose={() => setShowReviewModal(false)}
          refreshBookings={load}
        />
      )}

    </div>
  );
}
