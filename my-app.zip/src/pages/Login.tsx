'use client';

import React, { useState } from "react";
import { loginUser } from "../services/authService";
import { useNavigate, Link } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import "./Login.css";

function Login() {
  const { t } = useLanguage();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleLogin = async () => {

    setError("");
    setLoading(true);

    try {

      const data = await loginUser(email, password);

      const role = data?.user?.role;
      const token = data?.token;

      if (!role || !token) {
        throw new Error("Invalid login response");
      }

      // Save auth
      localStorage.setItem("token", token);
      localStorage.setItem("role", role);

      // Notify navbar / app auth change
      window.dispatchEvent(new Event("authChanged"));

      // Role based routes
      const roleRoutes: any = {
        provider: "/provider-dashboard",
        customer: "/search",
        admin: "/admin"
      };

      navigate(roleRoutes[role] || "/");

    } catch (err: any) {

      setError(
        err.response?.data?.msg ||
        err.message ||
        "Login failed. Please try again."
      );

    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleLogin();
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">

        <div className="auth-card">

          <div className="auth-header">
            <h1>{t('login.title')}</h1>
            <p>{t('login.subtitle')}</p>
          </div>

          {error && (
            <div className="error-message">
              ⚠️ {error}
            </div>
          )}

          <div className="form-group">
            <label>{t('login.email')}</label>
            <input
              type="email"
              placeholder={t('login.emailPlaceholder')}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={handleKeyPress}
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label>{t('login.password')}</label>
            <input
              type="password"
              placeholder={t('login.passwordPlaceholder')}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={handleKeyPress}
              disabled={loading}
            />
          </div>

          <button
            onClick={handleLogin}
            className="login-btn"
            disabled={loading}
          >
            {loading ? t('login.signingIn') : t('login.signIn')}
          </button>

          <p className="auth-footer">
            {t('login.noAccount')} <Link to="/register">{t('login.createOne')}</Link>
          </p>

        </div>

        <div className="auth-benefits">
          <h3>{t('login.benefitsTitle')}</h3>
          <ul>
            <li>{t('login.benefit1')}</li>
            <li>{t('login.benefit2')}</li>
            <li>{t('login.benefit3')}</li>
            <li>{t('login.benefit4')}</li>
          </ul>
        </div>

      </div>
    </div>
  );
}

export default Login;
