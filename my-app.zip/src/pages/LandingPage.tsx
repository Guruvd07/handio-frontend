import { Link } from "react-router-dom"
import { useState } from "react"

import HeroSection from "../components/HeroSection"
import HowItWorks from "../components/HowItWorks"
import FeaturesSection from "../components/FeaturesSection"
import ContactSection from "../components/ContactSection"
import Footer from "../components/Footer"
import logo from "../logo/logo.png"
import { useLanguage } from "../context/LanguageContext"
import type { Language } from "../i18n/translations";
import "./LandingPage.css"
import FeaturedProviders from "../components/FeaturedProviders"
import ServiceCategories from "../components/ServiceCategories"
import StatsSection from "../components/StatsSection"
import BecomeProviderCTA from "../components/BecomeProviderCTA"

function LandingPage() {
  const { t, language, setLanguage } = useLanguage()
  
  const [showLangDropdown, setShowLangDropdown] = useState(false)

  const languages: { code: Language; name: string; flag: string }[] = [
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'mr', name: 'मराठी', flag: '🇮🇳' },
    { code: 'bn', name: 'বাংলা', flag: '🇮🇳' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'te', name: 'తెలుగు', flag: '🇮🇳' },
    { code: 'kn', name: 'ಕನ್ನಡ', flag: '🇮🇳' },
  ]

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang)
    setShowLangDropdown(false)
  }

  return (
    <div className="landing-container">

      {/* Navbar */}
      <nav className="landing-navbar">

      <div className="logo">
        <img src={logo} alt="Handio Logo" />
      </div>

        <div className="nav-links">

          <a href="#services">{t('landing.services')}</a>
          <a href="#contact">{t('landing.contact')}</a>

          {/* Language Toggle Dropdown */}
          <div className="language-dropdown">
            <button 
              className="language-toggle-btn"
              onClick={() => setShowLangDropdown(!showLangDropdown)}
              title="Change Language"
            >
              🌐 {language.toUpperCase()}
            </button>
            
            {showLangDropdown && (
              <div className="language-menu">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    className={`language-option ${language === lang.code ? 'active' : ''}`}
                    onClick={() => handleLanguageChange(lang.code)}
                  >
                    <span className="lang-flag">{lang.flag}</span>
                    <span className="lang-name">{lang.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <Link to="/login">
            <button className="login-btn">
              {t('navbar.login')}
            </button>
          </Link>

          <Link to="/register">
            <button className="register-btn">
              {t('navbar.register')}
            </button>
          </Link>

        </div>

      </nav>

      {/* Hero */}
      <HeroSection />

      {/* Services */}
      {/* <ServicesSection /> */}
      <ServiceCategories />

      <FeaturedProviders />
      

      {/* How It Works */}
      <HowItWorks />
      <StatsSection />

      <BecomeProviderCTA />

      {/* Features */}
      <FeaturesSection />

      {/* Contact */}
      <ContactSection />

      {/* Footer */}
      <Footer />

    </div>
  )
}

export default LandingPage
