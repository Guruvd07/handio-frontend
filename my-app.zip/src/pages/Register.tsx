'use client';

import React from "react"

import { useState } from "react";
import { registerUser } from "../services/authService";
import { useNavigate, Link } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import "./Register.css";

function Register() {
  const { t } = useLanguage();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("customer");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleRegister = async () => {
    setError("");
    if (!name || !email || !password) {
      setError(t('register.fillAllFields'));
      return;
    }
    
    setLoading(true);
    try {
      const data = await registerUser(
        name,
        email,
        password,
        role
      );

      localStorage.setItem("token", data.token);
      localStorage.setItem("role", role);

      navigate("/");
    } catch (err: any) {
      setError(err.response?.data?.msg || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleRegister();
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <h1>{t('register.title')}</h1>
            <p>{t('register.subtitle')}</p>
          </div>

          {error && (
            <div className="error-message">
              ⚠️ {error}
            </div>
          )}

          <div className="role-selector">
            <label className={`role-option ${role === "customer" ? "active" : ""}`}>
              <input
                type="radio"
                value="customer"
                checked={role === "customer"}
                onChange={e => setRole(e.target.value)}
              />
              <span>{t('register.customerRole')}</span>
            </label>
            <label className={`role-option ${role === "provider" ? "active" : ""}`}>
              <input
                type="radio"
                value="provider"
                checked={role === "provider"}
                onChange={e => setRole(e.target.value)}
              />
              <span>{t('register.providerRole')}</span>
            </label>
          </div>

          <div className="form-group">
            <label htmlFor="name">{t('register.fullName')}</label>
            <input
              id="name"
              type="text"
              placeholder={t('register.fullNamePlaceholder')}
              value={name}
              onChange={e => setName(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">{t('register.email')}</label>
            <input
              id="email"
              type="email"
              placeholder={t('register.emailPlaceholder')}
              value={email}
              onChange={e => setEmail(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">{t('register.password')}</label>
            <input
              id="password"
              type="password"
              placeholder={t('register.passwordPlaceholder')}
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={loading}
            />
          </div>

          <button 
            onClick={handleRegister}
            className="register-btn"
            disabled={loading}
          >
            {loading ? t('register.creating') : t('register.create')}
          </button>

          <p className="auth-footer">
            {t('register.haveAccount')} <Link to="/login">{t('register.signIn')}</Link>
          </p>
        </div>

        <div className="auth-benefits">
          <h3>{role === "customer" ? t('register.benefitsTitle') : t('register.benefitsTitle2')}</h3>
          <ul>
            {role === "customer" ? (
              <>
                <li>{t('register.benefitCust1')}</li>
                <li>{t('register.benefitCust2')}</li>
                <li>{t('register.benefitCust3')}</li>
                <li>{t('register.benefitCust4')}</li>
              </>
            ) : (
              <>
                <li>{t('register.benefitProv1')}</li>
                <li>{t('register.benefitProv2')}</li>
                <li>{t('register.benefitProv3')}</li>
                <li>{t('register.benefitProv4')}</li>
              </>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Register;
