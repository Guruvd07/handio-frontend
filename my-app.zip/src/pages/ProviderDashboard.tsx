'use client';

import { useEffect, useState } from "react";
import {
  getProviderBookings,
  updateBookingStatus
} from "../services/bookingService";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import api from "../api/axios";
import "./ProviderDashboard.css";

function ProviderDashboard() {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const [bookings, setBookings] = useState<any[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [loading, setLoading] = useState<boolean>(false);

  /* PROFILE PHOTO STATES */

  const [profileImage, setProfileImage] = useState<string>("");
  const [uploadingPhoto, setUploadingPhoto] = useState<boolean>(false);

  /* =========================
     LOAD DATA ON PAGE LOAD
  ========================= */

  useEffect(() => {
    loadBookings();
    loadProfile();   // ⭐ load saved photo
  }, []);

  /* =========================
     LOAD PROFILE
  ========================= */

  const loadProfile = async () => {

    try {

      const token = localStorage.getItem("token");

      const res = await api.get(
        "/providers/me",
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      if (res.data?.profilePhoto) {
        setProfileImage(res.data.profilePhoto);
      }

    } catch (err) {

      console.error("Failed to load profile", err);

    }

  };

  /* =========================
     LOAD BOOKINGS
  ========================= */

  const loadBookings = async () => {

    try {

      setLoading(true);

      const token = localStorage.getItem("token")!;
      const data = await getProviderBookings(token);

      setBookings(data);

    } catch (err) {

      console.error("Failed to load bookings", err);

    } finally {

      setLoading(false);

    }

  };

  /* =========================
     UPDATE BOOKING STATUS
  ========================= */

  const update = async (id: string, status: string) => {

    try {

      const token = localStorage.getItem("token")!;
      await updateBookingStatus(id, status, token);

      setBookings(prev =>
        prev.map(b =>
          b._id === id ? { ...b, status } : b
        )
      );

    } catch (err) {

      console.error("Failed to update booking", err);
      alert("Failed to update booking");

    }

  };

  /* =========================
     PROFILE PHOTO UPLOAD
  ========================= */

  const uploadProfilePhoto = async (file: File) => {

    try {
  
      setUploadingPhoto(true);
  
      const formData = new FormData();
      formData.append("image", file);
  
      const res = await api.post(
        "/providers/upload-photo",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        }
      );
  
      console.log("UPLOAD RESPONSE:", res.data);
  
      setProfileImage(res.data.profilePhoto);
  
    } catch (err) {
  
      console.error("Upload failed", err);
  
    } finally {
  
      setUploadingPhoto(false);
  
    }
  
  };


  /* =========================
   DELETE PROFILE PHOTO
========================= */

const deletePhoto = async () => {

  if (!window.confirm("Remove profile photo?")) return;

  try {

    const token = localStorage.getItem("token");

    await api.delete(
      "/providers/profile-photo",
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );

    setProfileImage("");

  } catch (err) {

    console.error("Delete failed", err);

  }

};

  /* =========================
     FILTER BOOKINGS
  ========================= */

  const filteredBookings =
    filter === "all"
      ? bookings
      : bookings.filter(b => b.status === filter);

  const stats = {
    total: bookings.length,
    pending: bookings.filter(b => b.status === "pending").length,
    accepted: bookings.filter(b => b.status === "accepted").length,
    rejected: bookings.filter(b => b.status === "rejected").length,
  };

  return (
    <div className="provider-dashboard-page">

      {/* PROFILE PHOTO */}

      <div className="profile-section">

          <div className="profile-card">

          <div className="profile-photo-container">

            {profileImage ? (

              <div className="photo-wrapper">

                <img
                  src={profileImage}
                  alt="profile"
                  className="profile-photo"
                />

                <button
                  className="delete-photo-btn"
                  onClick={deletePhoto}
                >
                  {t('providerDashboard.removePhoto')}
                </button>

              </div>

            ) : (

              <div className="profile-placeholder">
                {t('providerDashboard.uploadPhoto')}
              </div>

            )}

            </div>

            

            <div className="profile-upload">

              <h3>{t('providerDashboard.profilePhoto')}</h3>

              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  if (e.target.files?.[0]) {
                    uploadProfilePhoto(e.target.files[0]);
                  }
                }}
              />

              <p className="upload-hint">
                {t('providerDashboard.uploadHint')}
              </p>

            </div>

          </div>

        </div>

      {/* PORTFOLIO */}

      <div className="portfolio-manage">

        <h2>{t('providerDashboard.workPortfolio')}</h2>

        <button
          className="portfolio-btn"
          onClick={() => navigate("/upload-portfolio")}
        >
          {t('providerDashboard.managePortfolio')}
        </button>

      </div>

      {/* DASHBOARD HEADER */}

      <div className="dashboard-header">
        <h1>{t('providerDashboard.bookingRequests')}</h1>
        <p>{t('providerDashboard.manageRequests')}</p>
      </div>

      {/* STATS */}

      <div className="stats-grid">

        <div className="stat-card">
          <span className="stat-number">{stats.total}</span>
          <span className="stat-label">{t('providerDashboard.totalBookings')}</span>
        </div>

        <div className="stat-card pending">
          <span className="stat-number">{stats.pending}</span>
          <span className="stat-label">{t('providerDashboard.pending')}</span>
        </div>

        <div className="stat-card accepted">
          <span className="stat-number">{stats.accepted}</span>
          <span className="stat-label">{t('providerDashboard.accepted')}</span>
        </div>

        <div className="stat-card rejected">
          <span className="stat-number">{stats.rejected}</span>
          <span className="stat-label">{t('providerDashboard.rejected')}</span>
        </div>

      </div>

      {/* FILTER */}

      <div className="filter-tabs">

        {["all", "pending", "accepted", "rejected"].map(status => {
          const statusLabels: { [key: string]: string } = {
            'all': t('providerDashboard.pending'),
            'pending': t('providerDashboard.pending'),
            'accepted': t('providerDashboard.accepted'),
            'rejected': t('providerDashboard.rejected'),
          };

          return (
            <button
              key={status}
              className={`filter-tab ${filter === status ? "active" : ""}`}
              onClick={() => setFilter(status)}
            >
              {status === 'all' ? 'All' : statusLabels[status]}
            </button>
          );
        })}

      </div>

      {/* BOOKINGS */}

      {loading ? (

        <div className="no-bookings">
          <p>{t('providerDashboard.loadingBookings')}</p>
        </div>

      ) : filteredBookings.length === 0 ? (

        <div className="no-bookings">
          <p>
            😊 {t('providerDashboard.noBookings')}
          </p>
        </div>

      ) : (

        <div className="bookings-list">

          {filteredBookings.map(b => {

            const customerName = b.customerId?.name ?? "Customer";
            const avatar = customerName.charAt(0).toUpperCase();

            return (

              <div
                key={b._id}
                className={`booking-item status-${b.status}`}
              >

                <div className="booking-header">

                  <div className="customer-info">

                    <div className="customer-avatar">
                      {avatar}
                    </div>

                    <div>
                      <h3>{customerName}</h3>

                      <p className="booking-date">
                        📅 {b.date
                          ? new Date(b.date).toLocaleDateString()
                          : "No date"}
                      </p>
                    </div>

                  </div>

                  <div className={`status-badge status-${b.status}`}>
                    {b.status.toUpperCase()}
                  </div>

                </div>

                <div className="booking-details">

                  <p className="booking-note">
                    <strong>{t('providerDashboard.notes')}:</strong>{" "}
                    {b.note || t('providerDashboard.noAdditionalNotes')}
                  </p>

                </div>

                {b.status === "pending" && (

                  <div className="booking-actions">

                    <button
                      onClick={() => update(b._id, "accepted")}
                      className="btn-accept"
                    >
                      {t('providerDashboard.accept')}
                    </button>

                    <button
                      onClick={() => update(b._id, "rejected")}
                      className="btn-reject"
                    >
                      {t('providerDashboard.reject')}
                    </button>

                  </div>

                )}

                {b.status === "accepted" && (

                  <div className="booking-actions">

                    <button
                      onClick={() => update(b._id, "completed")}
                      className="btn-complete"
                    >
                      {t('providerDashboard.markCompleted')}
                    </button>

                  </div>

                )}

              </div>

            );

          })}

        </div>

      )}

    </div>
  );
}

export default ProviderDashboard;
