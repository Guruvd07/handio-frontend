'use client';

import { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import "./SearchProviders.css";

function SearchProviders() {
  const { t } = useLanguage();

  const [filters, setFilters] = useState<any>({
    categories: [],
    cities: [],
    areas: []
  });

  const [category, setCategory] = useState("");
  const [city, setCity] = useState("");
  const [area, setArea] = useState("");

  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadFilters();
  }, []);

  const loadFilters = async () => {
    try {
      const res = await axios.get(
        "http://localhost:5000/providers/filters/options"
      );
      setFilters(res.data);
    } catch (err) {
      console.error("Failed to load filters", err);
    }
  };

  const search = async () => {
    try {
      setLoading(true);

      const res = await axios.get(
        "http://localhost:5000/providers",
        {
          params: { category, city, area }
        }
      );

      setResults(res.data);

    } catch (err) {
      console.error("Search failed", err);
    } finally {
      setLoading(false);
    }
  };

  // Helper function to format name - ONLY UI improvement, no backend changes
  const formatName = (name) => {
    if (!name || name === "Unknown") return name;
    return name
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  };

  return (
    <div className="search-providers-page">
      <div className="search-container">

        <div className="search-header">
          <h1>{t('searchProviders.title')}</h1>
          <p>{t('searchProviders.subtitle')}</p>
        </div>

        <div className="filters-section">

          <select
            value={category}
            onChange={e => setCategory(e.target.value)}
            className="filter-select"
          >
            <option value="">{t('searchProviders.selectCategory')}</option>
            {filters.categories.map((c: any) =>
              <option key={c} value={c}>{c}</option>
            )}
          </select>

          <select
            value={city}
            onChange={e => setCity(e.target.value)}
            className="filter-select"
          >
            <option value="">{t('searchProviders.selectCity')}</option>
            {filters.cities.map((c: any) =>
              <option key={c} value={c}>{c}</option>
            )}
          </select>

          <select
            value={area}
            onChange={e => setArea(e.target.value)}
            className="filter-select"
          >
            <option value="">{t('searchProviders.selectArea')}</option>
            {filters.areas.map((a: any) =>
              <option key={a} value={a}>{a}</option>
            )}
          </select>

          <button
            onClick={search}
            className="search-btn"
            disabled={loading}
          >
            {loading ? t('searchProviders.searching') : t('searchProviders.search')}
          </button>

        </div>
      </div>

      <div className="results-container">

        {results.length === 0 && !loading && (
          <div className="no-results">
            <p>👀 {t('searchProviders.noResults')}</p>
          </div>
        )}

        {loading && (
          <div className="loading">
            <p>{t('searchProviders.findingProviders')}</p>
          </div>
        )}

        <div className="providers-grid">

          {results.map(p => {

          const name = p.userId?.name ?? "Unknown";
          // Format the name for better display - UI only change
          const formattedName = formatName(name);
          const avatar = name.charAt(0).toUpperCase();
          const photo = p.profilePhoto;

            return (
              <Link
                to={`/provider/${p._id}`}
                key={p._id}
                className="provider-card-link"
              >

                <div className="provider-card">

                <div className="provider-header">

                <img
                  src={p.profilePhoto || "https://placehold.co/400"}
                  className="provider-image"
                  alt={formattedName}
                />

                <div className="provider-info">

                  <h3 className="provider-name" title={formattedName}>
                    {formattedName}
                  </h3>

                  <span className="provider-category">
                    {p.category}
                  </span>

                </div>

                </div>
                  <div className="provider-location">
                    <span>📍 {p.city}, {p.area}</span>
                  </div>

                  <div className="provider-price-rating">
                  <div className="price">
                    {p.priceAmount && p.priceType
                      ? `₹${p.priceAmount} / ${p.priceType}`
                      : t('searchProviders.priceNotSpecified')}
                  </div>

                  <div className="rating">
                    ⭐ {p.averageRating?.toFixed(1) || "N/A"}
                  </div>
                </div>


                  <button className="view-profile-btn">
                    {t('searchProviders.viewProfile')}
                  </button>

                </div>

              </Link>
            );
          })}

        </div>

      </div>
    </div>
  );
}

export default SearchProviders;
