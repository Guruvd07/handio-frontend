'use client';

import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";
import { fetchProviderById } from "../services/providerService";
import { createBooking } from "../services/bookingService";
import "./ProviderProfile.css";

function ProviderProfile() {
  const { t } = useLanguage();
  const { id } = useParams();
  const navigate = useNavigate();

  const [provider, setProvider] = useState<any>(null);
  const [date, setDate] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [reviews, setReviews] = useState<any[]>([]);

  useEffect(() => {

    fetchProviderById(id!).then(setProvider);

    fetch(`http://localhost:5000/reviews/provider/${id}`)
      .then(res => res.json())
      .then(data => setReviews(data))
      .catch(err => console.error(err));

  }, [id]);

  const formatPrice = () => {

    if (!provider?.priceAmount) return "Price not specified";

    const type =
      provider.priceType
        ? provider.priceType.charAt(0).toUpperCase() +
          provider.priceType.slice(1)
        : "";

    return `₹${provider.priceAmount.toLocaleString()}${type ? ` / ${type}` : ""}`;

  };

  const handleBooking = async (e: React.FormEvent) => {

    e.preventDefault();

    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login");
      return;
    }

    if (!date) {
      alert(t('providerProfile.selectDate'));
      return;
    }

    setLoading(true);

    try {

      await createBooking(id!, date, note, token);

      setBookingSuccess(true);

      setTimeout(() => {
        navigate("/my-bookings");
      }, 2000);

    } catch (err) {

      alert(t('providerProfile.bookingFailed'));

    } finally {

      setLoading(false);

    }

  };

  if (!provider) {

    return (
      <div className="provider-profile-page">
        <div className="loading-state">
          <p>{t('providerProfile.loading') || 'Loading provider...'}</p>
        </div>
      </div>
    );

  }

  if (bookingSuccess) {

    return (
      <div className="provider-profile-page">
        <div className="success-message">
          <h2>{t('providerProfile.bookingSuccess')}</h2>
          <p>{t('providerProfile.redirecting') || 'Redirecting to your bookings...'}</p>
        </div>
      </div>
    );

  }

  const ratingValue =
    provider.averageRating
      ? parseFloat(provider.averageRating).toFixed(1)
      : "N/A";

  return (

    <div className="provider-profile-page">

      {/* HERO SECTION */}

      <div className="profile-hero">

        <div className="hero-content">

        <img
          src={
            provider.profilePhoto ||
            "https://placehold.co/120"
          }
          alt="provider"
          className="provider-avatar-img"
        />

          <div className="hero-text">

            <h1>{provider.userId?.name}</h1>

            <p className="service-category">
              {provider.category}
            </p>

            <div className="hero-stats">

              <div className="stat">
                ⭐ {ratingValue}
              </div>

              <div className="stat">
                {formatPrice()}
              </div>

              <div className="stat">
                📍 {provider.area}
              </div>

            </div>

          </div>

          {/* BOOK BUTTON ALWAYS VISIBLE */}

          <div className="hero-book">

            <button
              className="book-now-btn"
              onClick={() => {
                document
                  .getElementById("booking-section")
                  ?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              {t('providerProfile.bookNow')}
            </button>

          </div>

        </div>

      </div>

      {/* MAIN LAYOUT */}

      <div className="profile-container">

        {/* LEFT CONTENT */}

        <div className="profile-main">

          <section className="section">
            <h2>About This Service</h2>
            <p>{provider.description}</p>
          </section>

          {/* PORTFOLIO */}

          {provider.portfolio?.length > 0 && (

            <section className="section">

              <h2>Work Portfolio</h2>

              <div className="portfolio-grid">

                {provider.portfolio.map((item:any, index:number) => (

                  <img
                    key={index}
                    src={item.imageUrl}
                    className="portfolio-image"
                  />

                ))}

              </div>

            </section>

          )}

          {/* REVIEWS */}

          <section className="section">

            <h2>Customer Reviews</h2>

            {reviews.length === 0 ? (

              <p>No reviews yet.</p>

            ) : (

              reviews.map((r:any) => (

                <div key={r._id} className="review-card">

                  <strong>
                    {r.customerId?.name || "Customer"}
                  </strong>

                  <span>
                    {"⭐".repeat(r.rating)}
                  </span>

                  <p>{r.comment}</p>

                </div>

              ))

            )}

          </section>

        </div>

        {/* BOOKING SIDEBAR */}

        <aside
          id="booking-section"
          className="booking-sidebar"
        >

          <div className="booking-card">

            <h3>Book Service</h3>

            <form onSubmit={handleBooking}>

              <input
                type="date"
                value={date}
                onChange={(e) =>
                  setDate(e.target.value)
                }
                required
              />

              <textarea
                placeholder="Add notes..."
                value={note}
                onChange={(e) =>
                  setNote(e.target.value)
                }
              />

              <button
                type="submit"
                className="book-btn"
                disabled={loading}
              >

                {loading
                  ? "Sending..."
                  : "Request Booking"}

              </button>

            </form>

          </div>

        </aside>

      </div>

    </div>

  );

}

export default ProviderProfile;
