import { useEffect, useState, useRef } from "react"
import { useLanguage } from "../context/LanguageContext"
import "./StatsSection.css"

function StatsSection() {
  const { t } = useLanguage()
  const sectionRef = useRef(null)
  const [counts, setCounts] = useState([])
  const [hasAnimated, setHasAnimated] = useState(false)

  const stats = [
    { value: 50000, label: t("stats.customers"), suffix: "+", icon: "👥" },
    { value: 2500, label: t("stats.providers"), suffix: "+", icon: "🛠️" },
    { value: 15, label: t("stats.cities"), suffix: "+", icon: "🏙️" },
    { value: 4.8, label: t("stats.rating"), suffix: "★", icon: "⭐" }
  ]

  useEffect(() => {
    setCounts(stats.map(() => 0))
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true)
          
          // Smooth counting animation
          const duration = 2000
          const steps = 60
          const interval = duration / steps
          let step = 0

          const timer = setInterval(() => {
            step++
            const progress = Math.min(step / steps, 1)
            // Easing function for smoother animation
            const eased = 1 - Math.pow(1 - progress, 3)
            
            setCounts(stats.map(stat => {
              return stat.value * eased
            }))

            if (step >= steps) {
              clearInterval(timer)
            }
          }, interval)

          return () => clearInterval(timer)
        }
      },
      { threshold: 0.3 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [hasAnimated])

  const formatNumber = (num, originalValue) => {
    if (Number.isInteger(originalValue)) {
      return Math.floor(num).toLocaleString()
    }
    return num.toFixed(1)
  }

  return (
    <section className="stats-section" ref={sectionRef}>
      <div className="stats-container">
        {stats.map((stat, i) => (
          <div key={i} className="stat-card">
            <div className="stat-icon">{stat.icon}</div>
            <h2>
              {formatNumber(counts[i] || 0, stat.value)}
              {stat.suffix}
            </h2>
            <p>{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

export default StatsSection