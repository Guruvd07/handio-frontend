import "./HeroSection.css"
import { Link } from "react-router-dom"
import { useState, useEffect, useRef } from "react"
import { useLanguage } from "../context/LanguageContext"

function HeroSection() {
  const { t } = useLanguage()
  const [isVisible, setIsVisible] = useState(false)
  const [counts, setCounts] = useState({ professionals: 0, rating: 0, guarantee: 0 })
  const heroRef = useRef(null)
  
  // Intersection Observer for scroll animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.3 }
    )

    if (heroRef.current) {
      observer.observe(heroRef.current)
    }

    return () => observer.disconnect()
  }, [])

  // Counter animation when section becomes visible
  useEffect(() => {
    if (isVisible) {
      const duration = 2000 // 2 seconds
      const steps = 60
      const interval = duration / steps
      
      let step = 0
      const timer = setInterval(() => {
        step++
        const progress = step / steps
        
        setCounts({
          professionals: Math.min(Math.round(50 * progress), 50),
          rating: (4.9 * Math.min(progress, 1)).toFixed(1),
          guarantee: Math.min(Math.round(100 * progress), 100)
        })

        if (step >= steps) {
          clearInterval(timer)
        }
      }, interval)

      return () => clearInterval(timer)
    }
  }, [isVisible])

  // Typing effect for the title - FIXED VERSION
  const [displayTitle, setDisplayTitle] = useState("")
  const [titleIndex, setTitleIndex] = useState(0)
  const fullTitle = t('hero.titlePart1')
  const highlightText = t('hero.titlePart2')
  
  useEffect(() => {
    if (isVisible && titleIndex < fullTitle.length) {
      const timer = setTimeout(() => {
        setDisplayTitle(prev => prev + fullTitle[titleIndex])
        setTitleIndex(prev => prev + 1)
      }, 50)

      return () => clearTimeout(timer)
    }
  }, [titleIndex, isVisible, fullTitle])

  // Handle mouse move for parallax effect
  const handleMouseMove = (e) => {
    const { clientX, clientY } = e
    const x = (clientX / window.innerWidth - 0.5) * 20
    const y = (clientY / window.innerHeight - 0.5) * 20
    
    if (heroRef.current) {
      const accents = heroRef.current.querySelectorAll('.hero-accent')
      accents.forEach((accent, index) => {
        accent.style.transform = `translate(${x * (index + 1)}px, ${y * (index + 1)}px)`
      })
    }
  }

  // Handle scroll effect
  const [scrollY, setScrollY] = useState(0)
  
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <section 
      className="hero" 
      ref={heroRef}
      onMouseMove={handleMouseMove}
      style={{
        '--scroll-y': `${scrollY}px`
      }}
    >
      {/* Background overlay with gradient animation */}
      <div className="hero-background"></div>

      {/* Animated accent elements */}
      <div className="hero-accent top-accent"></div>
      <div className="hero-accent bottom-accent"></div>
      <div className="hero-accent middle-accent"></div>
      
      {/* Floating particles */}
      <div className="hero-particles">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i} 
            className="particle" 
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${5 + Math.random() * 10}s`
            }}
          />
        ))}
      </div>

      {/* Animated lines */}
      <div className="hero-lines">
        <div className="line line-1"></div>
        <div className="line line-2"></div>
        <div className="line line-3"></div>
      </div>

      {/* Main content */}
      <div className="hero-content">
        {/* Trust badge with hover effect */}
        <div className="trust-badge" role="status" aria-label="Trust badge">
          <span className="badge-icon">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M20 6L9 17L4 12" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </span>
          <span className="badge-text">{t('hero.trustedBadge')}</span>
          <span className="badge-shine"></span>
        </div>

        <h1 className="hero-title" aria-label="Hero title">
          {/* FIXED: Now displayTitle contains only "Find Trusted Local " */}
          {displayTitle}
          <span className="highlight">
            {highlightText}
          </span>
          <span className="cursor">|</span>
        </h1>

        <p className="hero-subtitle">
          {t('hero.subtitle')}
        </p>

        {/* Stats with counter animation */}
        <div className="hero-stats">
          <div className="stat" role="statistic">
            <span className="stat-number">{counts.professionals}K+</span>
            <span className="stat-label">{t('hero.stat1Label')}</span>
            <div className="stat-progress"></div>
          </div>
          <div className="stat" role="statistic">
            <span className="stat-number">{counts.rating}★</span>
            <span className="stat-label">{t('hero.stat2Label')}</span>
            <div className="stat-progress"></div>
          </div>
          <div className="stat" role="statistic">
            <span className="stat-number">{counts.guarantee}%</span>
            <span className="stat-label">{t('hero.stat3Label')}</span>
            <div className="stat-progress"></div>
          </div>
        </div>

        {/* CTA Buttons with ripple effect */}
        <div className="hero-buttons">
          <Link to="/register" className="btn-primary" aria-label="Get started">
            <span className="btn-icon">🚀</span>
            <span className="btn-text">{t('hero.btnGetStarted')}</span>
            <span className="btn-shine"></span>
          </Link>
          <Link to="/register" className="btn-secondary" aria-label="Become a provider">
            <span className="btn-icon">👷</span>
            <span className="btn-text">{t('hero.btnBecomeProvider')}</span>
            <span className="btn-shine"></span>
          </Link>
        </div>

        {/* Floating service icons */}
        <div className="floating-icons">
          <div className="floating-icon icon-1" style={{ transform: `translateY(${Math.sin(Date.now() / 1000) * 10}px)` }}>
            🔧
          </div>
          <div className="floating-icon icon-2" style={{ transform: `translateY(${Math.sin(Date.now() / 1000 + 2) * 15}px)` }}>
            🔌
          </div>
          <div className="floating-icon icon-3" style={{ transform: `translateY(${Math.sin(Date.now() / 1000 + 4) * 12}px)` }}>
            🧹
          </div>
        </div>
      </div>

     
    </section>
  )
}

export default HeroSection
