import "./FeaturesSection.css"
import { useLanguage } from "../context/LanguageContext"

function FeaturesSection() {
  const { t } = useLanguage()

  return (
    <section className="features">

      <h2>{t('features.title')}</h2>

      <div className="features-grid">

        <div>{t('features.feature1')}</div>
        <div>{t('features.feature2')}</div>
        <div>{t('features.feature3')}</div>
        <div>{t('features.feature4')}</div>

      </div>

    </section>
  )
}

export default FeaturesSection
