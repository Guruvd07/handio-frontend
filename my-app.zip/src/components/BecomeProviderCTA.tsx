import { useNavigate } from "react-router-dom"
import { useLanguage } from "../context/LanguageContext"
import "./BecomeProviderCTA.css"

function BecomeProviderCTA() {
  const navigate = useNavigate()
  const { t } = useLanguage()

  const handleJoin = () => {
    navigate("/register?role=provider")
  }

  const benefits = [
    { icon: "💰", title: "Extra Income", desc: "Earn ₹15,000 - ₹45,000 monthly" },
    { icon: "⏰", title: "Flexible Hours", desc: "Work when you want, full control" },
    { icon: "📱", title: "Direct Payments", desc: "Get paid directly to your account" }
  ]

  const previewStats = [
    { value: "2,500+", label: "Active Providers" },
    { value: "4.8★", label: "Average Rating" },
    { value: "50k+", label: "Monthly Bookings" }
  ]

  return (
    <section className="provider-cta">
      {/* Decorative floating elements */}
      <div className="floating-element-1">🚀</div>
      <div className="floating-element-2">💼</div>

      <div className="provider-cta-container">
        {/* Earnings Badge */}
        <div className="earnings-badge">
          ⚡ Earn up to ₹45,000/month
        </div>

        {/* Main Heading */}
        <h2>
          {t("cta.title")}{' '}
          <span>Your Skills, Your Schedule</span>
        </h2>

        {/* Description */}
        <p>
          {t("cta.subtitle") || 
            "Join 2,500+ trusted professionals in Pune. Set your own rates, choose your hours, and grow your business with zero investment."
          }
        </p>

        {/* Benefits Grid */}
        <div className="benefits-grid">
          {benefits.map((benefit, index) => (
            <div key={index} className="benefit-item">
              <span className="benefit-icon">{benefit.icon}</span>
              <h4>{benefit.title}</h4>
              <p>{benefit.desc}</p>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <button
          className="cta-btn"
          onClick={handleJoin}
        >
          {t("cta.button") || "Become a Provider →"}
        </button>

        {/* Stats Preview */}
        <div className="stats-preview">
          {previewStats.map((stat, index) => (
            <div key={index} className="stat-preview-item">
              <span className="stat-value">{stat.value}</span>
              <span className="stat-label">{stat.label}</span>
            </div>
          ))}
        </div>

        {/* Trust Badge */}
        <p style={{ 
          fontSize: '14px', 
          marginTop: '20px', 
          opacity: '0.7',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '5px'
        }}>
          <span>✓</span> Free registration <span style={{ margin: '0 10px' }}>•</span>
          <span>✓</span> Instant payout <span style={{ margin: '0 10px' }}>•</span>
          <span>✓</span> 24/7 support
        </p>
      </div>
    </section>
  )
}

export default BecomeProviderCTA