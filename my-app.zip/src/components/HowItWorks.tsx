import "./HowItWorks.css"
import { useState, useEffect, useRef } from "react"
import { useLanguage } from "../context/LanguageContext"

function HowItWorks() {
  const { t } = useLanguage()
  const [isVisible, setIsVisible] = useState(false)
  const [hoveredStep, setHoveredStep] = useState(null)
  const sectionRef = useRef(null)
  
  const steps = [
    {
      number: 1,
      title: t('howItWorks.step1Title'),
      description: t('howItWorks.step1Description'),
      icon: "🔍",
      color: "#3b82f6",
      detail: t('howItWorks.step1Detail')
    },
    {
      number: 2,
      title: t('howItWorks.step2Title'),
      description: t('howItWorks.step2Description'),
      icon: "📅",
      color: "#4ecdc4",
      detail: t('howItWorks.step2Detail')
    },
    {
      number: 3,
      title: t('howItWorks.step3Title'),
      description: t('howItWorks.step3Description'),
      icon: "⚙️",
      color: "#45b7d1",
      detail: t('howItWorks.step3Detail')
    },
    {
      number: 4,
      title: t('howItWorks.step4Title'),
      description: t('howItWorks.step4Description'),
      icon: "⭐",
      color: "#96ceb4",
      detail: t('howItWorks.step4Detail')
    }
  ]

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section className="how-section" ref={sectionRef}>
      {/* Animated wave lines */}
      <div className="wave-lines">
        <div className="wave wave-1"></div>
        <div className="wave wave-2"></div>
      </div>

      {/* Floating particles */}
      <div className="floating-particles">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="particle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              width: `${2 + Math.random() * 4}px`,
              height: `${2 + Math.random() * 4}px`,
              background: `rgba(255, 255, 255, ${0.2 + Math.random() * 0.3})`
            }}
          />
        ))}
      </div>

      <div className="how-container">
        {/* Header with subtle animation */}
        <div className="how-header">
          <span className={`how-badge ${isVisible ? 'fade-in' : ''}`}>
            {t('howItWorks.badge')}
          </span>
          <h2 className={isVisible ? 'fade-in' : ''}>
            {t('howItWorks.title')} <span className="gradient-text">Works</span>
          </h2>
          <p className={`how-subtitle ${isVisible ? 'fade-in' : ''}`}>
            {t('howItWorks.subtitle')}
          </p>
        </div>

        {/* Steps Grid */}
        <div className="steps-grid">
          {steps.map((step, index) => (
            <div 
              key={index} 
              className={`step-card ${isVisible ? 'fade-in' : ''} ${hoveredStep === index ? 'hovered' : ''}`}
              style={{ 
                animationDelay: `${index * 0.15}s`,
                '--step-color': step.color 
              }}
              onMouseEnter={() => setHoveredStep(index)}
              onMouseLeave={() => setHoveredStep(null)}
            >
              {/* Number with gradient */}
              <div className="step-number-wrapper">
                <div className="step-number">{step.number}</div>
                <div className="step-number-glow"></div>
              </div>

              {/* Icon with animation */}
              <div className="step-icon-wrapper">
                <div className="step-icon">
                  {step.icon}
                </div>
              </div>

              {/* Content */}
              <h3 className="step-title">{step.title}</h3>
              <p className="step-description">{step.description}</p>

              {/* Hover detail */}
              <div className="step-hover-detail">
                <span className="detail-dot"></span>
                <span className="detail-text">{step.detail}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Simple progress indicator */}
        <div className="how-progress">
          <div className="progress-line">
            <div className="progress-fill" style={{ width: '100%' }}></div>
          </div>
          <div className="progress-steps">
            <span>{t('howItWorks.progressStep1')}</span>
            <span>{t('howItWorks.progressStep2')}</span>
            <span>{t('howItWorks.progressStep3')}</span>
            <span>{t('howItWorks.progressStep4')}</span>
          </div>
        </div>

        {/* Footer with subtle animation */}
        <div className="how-footer">
          <p className={isVisible ? 'fade-in' : ''}>
            {t('howItWorks.footer')}
          </p>
        </div>
      </div>
    </section>
  )
}

export default HowItWorks
