import "./ContactSection.css"
import { useLanguage } from "../context/LanguageContext"

function ContactSection() {
  const { t } = useLanguage()

  return (
    <section className="contact" id="contact">

      <h2>{t('contact.title')}</h2>

      <p>{t('contact.email')}</p>
      <p>{t('contact.phone')}</p>
      <p>{t('contact.location')}</p>

    </section>
  )
}

export default ContactSection
