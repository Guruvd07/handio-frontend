'use client';

import { Link, useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import logo from "../logo/logo.png";
import { useLanguage } from "../context/LanguageContext";
import type { Language } from "../i18n/translations";
import "./Navbar.css";

function Navbar() {
  const navigate = useNavigate();
  const location = useLocation(); // detect route change
  const { language, setLanguage, t } = useLanguage();

  const [role, setRole] = useState<string | null>(null);
  const [loggedIn, setLoggedIn] = useState(false);
  const [showLangDropdown, setShowLangDropdown] = useState(false);

  const languages: { code: Language; name: string; flag: string }[] = [
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'mr', name: 'मराठी', flag: '🇮🇳' },
    { code: 'bn', name: 'বাংলা', flag: '🇮🇳' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'te', name: 'తెలుగు', flag: '🇮🇳' },
    { code: 'kn', name: 'ಕನ್ನಡ', flag: '🇮🇳' },
  ];

  const refreshAuth = () => {
    const r = localStorage.getItem("role");
    const token = localStorage.getItem("token");

    setRole(r);
    setLoggedIn(!!token);
  };

  // run whenever route changes
  useEffect(() => {
    refreshAuth();
  }, [location]);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/login");
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    setShowLangDropdown(false);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">

        <Link to="/" className="navbar-logo">
          <img src={logo} alt="Handio Logo" className="navbar-logo-img" />
        </Link>

        <div className="navbar-links">

          {!loggedIn && (
            <>
              <Link to="/login" className="nav-link">{t('navbar.login')}</Link>
              <Link to="/register" className="nav-link nav-link-register">{t('navbar.register')}</Link>
            </>
          )}

          {loggedIn && role === "customer" && (
            <>
              <Link to="/" className="nav-link">{t('navbar.search')}</Link>
              <Link to="/my-bookings" className="nav-link">{t('navbar.myBookings')}</Link>
            </>
          )}

          {loggedIn && role === "provider" && (
            <>
              <Link to="/provider-dashboard" className="nav-link">{t('navbar.dashboard')}</Link>
              <Link to="/create-provider-profile" className="nav-link">{t('navbar.createProfile')}</Link>
            </>
          )}

          {loggedIn && role === "admin" && (
            <>
              <Link to="/admin" className="nav-link">{t('navbar.admin')}</Link>
            </>
          )}

          {/* Language Toggle Dropdown */}
          <div className="language-dropdown">
            <button 
              className="language-toggle-btn"
              onClick={() => setShowLangDropdown(!showLangDropdown)}
              title="Change Language"
            >
              🌐 {language.toUpperCase()}
            </button>
            
            {showLangDropdown && (
              <div className="language-menu">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    className={`language-option ${language === lang.code ? 'active' : ''}`}
                    onClick={() => handleLanguageChange(lang.code)}
                  >
                    <span className="lang-flag">{lang.flag}</span>
                    <span className="lang-name">{lang.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {loggedIn && (
            <button onClick={logout} className="nav-logout-btn">
              {t('navbar.logout')}
            </button>
          )}

        </div>
      </div>
    </nav>
  );
}

export default Navbar;
