import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import api from "../api/axios"
import "./FeaturedProviders.css"
import { translations } from "../i18n/translations"
import { useLanguage } from "../context/LanguageContext"

function FeaturedProviders() {

const navigate = useNavigate()
const { language } = useLanguage()

const [providers, setProviders] = useState<any[]>([])

useEffect(() => {
fetchProviders()
}, [])

const fetchProviders = async () => {
try {
const res = await api.get("/providers")
console.log(res.data)
setProviders(res.data)
} catch (err) {
console.error("Error fetching providers:", err)
}
}

return ( <section className="featured-providers">


  <h2>
    {translations[language]?.featuredProviders?.title || "Top Rated Professionals"}
  </h2>

  <div className="providers-grid">

    {providers.slice(0, 4).map((provider) => (

      <div className="provider-card" key={provider._id}>

        <img
          src={provider.profilePhoto || "/default-user.png"}
          alt="provider"
        />

        <h3>{provider.userId?.name || "Provider"}</h3>

        <p className="service">
          {provider.category || "Service"}
        </p>

        <p className="rating">
          ⭐ {provider.averageRating > 0
            ? provider.averageRating.toFixed(1)
            : translations[language]?.featuredProviders?.new || "New"}
        </p>

        <button
          onClick={() => navigate(`/provider/${provider._id}`)}
        >
          {translations[language]?.featuredProviders?.viewProfile || "View Profile"}
        </button>

      </div>

    ))}

  </div>

  <div className="view-all">

    <button onClick={() => navigate("/search")}>
      {translations[language]?.featuredProviders?.viewAll || "View All Providers"}
    </button>

  </div>

</section>


)
}

export default FeaturedProviders
