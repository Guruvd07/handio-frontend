import { useNavigate } from "react-router-dom"
import { useLanguage } from "../context/LanguageContext"
import "./ServiceCategories.css"

function ServiceCategories() {
  const navigate = useNavigate()
  const { t } = useLanguage()

  const services = [
    { name: "electrician", icon: "⚡", description: "Electrical repairs & installation" },
    { name: "plumber", icon: "🔧", description: "Plumbing & pipe fixes" },
    { name: "ac repair", icon: "❄️", description: "AC service & repair" },
    { name: "cleaning", icon: "🧹", description: "Professional cleaning" },
    { name: "cook", icon: "🍳", description: "Home cooking services" },
    { name: "deep cleaning", icon: "✨", description: "Intensive home cleaning" },
    { name: "appliance repair", icon: "🔨", description: "Fridge, WM & microwave repair" },
    { name: "carpenter", icon: "🪚", description: "Furniture & woodwork" },
    { name: "painter", icon: "🎨", description: "Home painting & coloring" },
    { name: "pest control", icon: "🦟", description: "Pest & termite control" }
  ]

  const handleClick = (service) => {
    navigate(`/providers?service=${service}`)
  }

  return (
    <section className="services-section">
      <h2>{t("landing.popularServices")}</h2>
      <p className="section-subtitle">
        {t("landing.popularServicesSubtitle")}
      </p>

      <div className="services-grid">
        {services.map((service, index) => (
          <div
            key={index}
            className="service-card"
            onClick={() => handleClick(service.name)}
            role="button"
            tabIndex={0}
            onKeyPress={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                handleClick(service.name)
              }
            }}
          >
            <div className="service-icon">
              {service.icon}
            </div>
            <p className="service-name">
              {service.name}
            </p>
            <small style={{ 
              fontSize: '12px', 
              color: '#718096', 
              marginTop: '5px',
              position: 'relative',
              zIndex: 1
            }}>
              {service.description}
            </small>
          </div>
        ))}
      </div>
    </section>
  )
}

export default ServiceCategories