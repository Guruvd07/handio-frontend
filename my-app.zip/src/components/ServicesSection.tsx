import "./ServicesSection.css"
import { useLanguage } from "../context/LanguageContext"

function ServicesSection() {
  const { t } = useLanguage()

  const services = [
    { nameKey: "electrician", icon: "⚡", descKey: "electricianDesc" },
    { nameKey: "plumber", icon: "🔧", descKey: "plumberDesc" },
    { nameKey: "cleaning", icon: "🧹", descKey: "cleaningDesc" },
    { nameKey: "acRepair", icon: "❄️", descKey: "acRepairDesc" },
    { nameKey: "painting", icon: "🎨", descKey: "paintingDesc" },
  ]

  return (
    <section className="services" id="services">
      <div className="services-container">
        <div className="services-header">
          <h2 className="services-title">{t('services.title')}</h2>
          <p className="services-subtitle">
            {t('services.subtitle')}
          </p>
        </div>

        <div className="services-grid">
          {services.map((service, index) => (
            <div key={index} className="service-card" style={{ animationDelay: `${index * 0.1}s` }}>
              <div className="service-icon-wrapper">
                <div className="service-icon">
                  {service.icon}
                </div>
              </div>
              
              <h3 className="service-name">{t(`services.${service.nameKey}`)}</h3>
              <p className="service-description">{t(`services.${service.descKey}`)}</p>
              
              <button className="service-cta">{t('services.bookNow')}</button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default ServicesSection
